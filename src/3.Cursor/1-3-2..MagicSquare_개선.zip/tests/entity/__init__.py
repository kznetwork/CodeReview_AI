"""Tests for entity layer."""
