"""MagicSquare root package."""
