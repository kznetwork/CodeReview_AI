import java.util.ArrayList;
import java.util.List;

public class App {
    public List<int[]> GET_THEM(List<int[]> InputList) {
        List<int[]> BAD_NAME = new ArrayList<>();

        for (int[] x : InputList) {
            if (x[0] == 4) {
                BAD_NAME.add(x);
            }
        }

        return BAD_NAME;
    }
}