package com.samsung.srp;

public class GuitarSpec {
    private final Maker maker;
    private final String model;
    private final Wood topWood;
    private final Wood backWood;
    private final int stringNum;

    public GuitarSpec(Maker maker, String model, Wood topWood, Wood backWood, int stringNum) {
        this.maker = maker;
        this.model = model;
        this.topWood = topWood;
        this.backWood = backWood;
        this.stringNum = stringNum;
    }

    public Maker getMaker() {
        return maker;
    }

    public String getModel() {
        return model;
    }

    public Wood getTopWood() {
        return topWood;
    }

    public Wood getBackWood() {
        return backWood;
    }

    public int getStringNum() {
        return stringNum;
    }
}