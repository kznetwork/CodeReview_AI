package com.samsung.srp;

public enum Maker {
    FENDER, GIBSON
}