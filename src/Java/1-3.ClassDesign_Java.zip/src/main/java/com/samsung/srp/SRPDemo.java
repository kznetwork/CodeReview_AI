package com.samsung.srp;

public class SRPDemo {
    public static void main(String[] args) {
        GuitarSpec stratSpec = new GuitarSpec(
                Maker.FENDER,
                "Stratocaster",
                Wood.MAPLE,
                Wood.MAHOGANY,
                6
        );

        Guitar myGuitar = new Guitar("V12345", 1500.0, stratSpec);

        System.out.println("--- 기타 정보 ---");
        System.out.println("시리얼 번호: " + myGuitar.getSerialNumber());
        System.out.println("제조사: " + myGuitar.getSpec().getMaker());
        System.out.println("모델명: " + myGuitar.getSpec().getModel());
        System.out.println("상판 목재: " + myGuitar.getSpec().getTopWood());
        System.out.println("후판 목재: " + myGuitar.getSpec().getBackWood());
        System.out.println("줄 수: " + myGuitar.getSpec().getStringNum());
        System.out.println("현재 가격: $" + myGuitar.getPrice());
    }
}