package com.samsung.srp;

public enum Wood {
    MAHOGANY, MAPLE
}