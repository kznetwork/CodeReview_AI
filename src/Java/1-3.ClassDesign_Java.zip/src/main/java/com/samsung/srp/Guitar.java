// package com.samsung.srp;

// // Maker, Wood는 enum으로 가정
// enum Maker {
//     FENDER, GIBSON, MARTIN
// }

// enum Wood {
//     MAHOGANY, MAPLE, ALDER, ROSEWOOD
// }

// public class Guitar {
//     private String serialNumber;
//     private double price;
//     private Maker maker;
//     private String model;
//     private Wood topWood;
//     private Wood backWood;
//     private int stringNum;

//     public Guitar(String serialNumber, double price, Maker maker,
//                   String model, Wood topWood, Wood backWood, int stringNum) {
//         this.serialNumber = serialNumber;
//         this.price = price;
//         this.maker = maker;
//         this.model = model;
//         this.topWood = topWood;
//         this.backWood = backWood;
//         this.stringNum = stringNum;
//     }

//     public String getSerialNumber() { return serialNumber; }
//     public double getPrice() { return price; }
//     public Maker getBuilder() { return maker; }
//     public String getType() { return model; }
//     public Wood getBackWood() { return backWood; }
//     public Wood getTopWood() { return topWood; }
//     public int getStringNum() { return stringNum; }
//     public String getModel() { return model; }
// }


package com.samsung.srp;

public class Guitar {
    private final String serialNumber;
    private double price;
    private final GuitarSpec spec;

    public Guitar(String serialNumber, double price, GuitarSpec spec) {
        this.serialNumber = serialNumber;
        this.price = price;
        this.spec = spec;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public GuitarSpec getSpec() {
        return spec;
    }
}