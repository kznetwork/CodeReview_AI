package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

class StubPatternTest {

    @Test
    void defaultReturn() {
        // Java – Stub 패턴
        MessageService mock = mock(MessageService.class);

        // 기본 반환
        when(mock.sendMessage(any(), any()))
            .thenReturn("default");

        assertEquals("default", mock.sendMessage("anyone", "anything"));
    }

    @Test
    void conditionalReturn() {
        MessageService mock = mock(MessageService.class);

        // 기본 반환
        when(mock.sendMessage(any(), any()))
            .thenReturn("default");

        // 조건별 반환
        when(mock.sendMessage(eq("vip"), any()))
            .thenReturn("priority");

        assertEquals("priority", mock.sendMessage("vip", "hello"));
        assertEquals("default",  mock.sendMessage("normal", "hello"));
    }

    @Test
    void throwException() {
        // 예외
        MessageService mock = mock(MessageService.class);
        when(mock.sendMessage(any(), any()))
            .thenThrow(new RuntimeException("network error"));

        assertThrows(RuntimeException.class,
            () -> mock.sendMessage("to", "msg"));
    }
}
