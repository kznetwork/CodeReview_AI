package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

class SpyTest {

    @Test
    void spyPartialOverride() {
        // Java Spy
        MessageService real = (to, msg) -> "real: " + msg;
        MessageService spy = spy(real);

        // 특정 호출만 가로채기
        doReturn("fake").when(spy)
            .sendMessage("to", "msg");

        assertEquals("fake",
            spy.sendMessage("to", "msg"));
        assertEquals("real: other",
            spy.sendMessage("to", "other"));
    }

    @Test
    void argumentMatchers() {
        // Argument Matchers
        MessageService mock = mock(MessageService.class);
        when(mock.sendMessage(anyString(), anyString()))
            .thenReturn("matched");

        mock.sendMessage("user", "hello");

        verify(mock).sendMessage(
            anyString(), anyString());
    }
}
