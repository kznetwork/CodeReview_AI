package com.example;

public interface MessageService {
    String sendMessage(String to, String msg);
}
