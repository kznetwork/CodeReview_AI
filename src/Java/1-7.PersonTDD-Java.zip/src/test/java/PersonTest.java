import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

// PersonTest.java
class PersonTest {
    private Person person;

    @BeforeEach
    void setUp() {
        person = new Person("홍길동");
    }

    @Test
    @DisplayName("이름 반환 확인")
    void testGetName() {
        assertEquals("홍길동", person.getName());
    }

    @Test
    @DisplayName("이름 변경 후 확인")
    void testSetName() {
        person.setName("이순신");
        assertEquals("이순신", person.getName());
    }

    @Test
    @DisplayName("null 이름 생성 시 예외")
    void testNullName() {
        assertThrows(IllegalArgumentException.class,
            () -> new Person(null));
    }
}
