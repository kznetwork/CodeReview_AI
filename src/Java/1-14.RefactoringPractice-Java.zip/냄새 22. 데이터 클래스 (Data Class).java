// ❌ 냄새 22 — 데이터 클래스 (행위 없음)
class Department {
    private String name;
    private List<Employee> staff;
    String getName(){return name;}
    void setName(String n){name=n;}
    List<Employee> getStaff(){return staff;}
    void setStaff(List<Employee> s){staff=s;}
    // 행위가 전혀 없음!
}

// ✅ After — 행위 이동 + setter 제거
// class Department {
//     private final String name;  // 불변
//     private final List<Employee> staff =
//         new ArrayList<>();
//     Department(String name){this.name=name;}
//     void addEmployee(Employee e){staff.add(e);}
//     int headCount(){return staff.size();}
//     double totalSalary(){
//         return staff.stream()
//             .mapToDouble(e->e.salary).sum();
//     }
// }
