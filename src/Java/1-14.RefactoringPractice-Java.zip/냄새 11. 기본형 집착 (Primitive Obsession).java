// ❌ 냄새 11 — 기본형 집착
double price = 19.99;

// ✅ After 1 — 기본형을 객체로
// class Price {
//     private final double value;
//     Price(double v){
//         if(v<0) throw new
//           IllegalArgumentException();
//         value = v;
//     }
//     double getValue(){ return value; }
//     public String toString(){
//         return String.format("$%.2f",value);
//     }
// }

// ✅ After 2 — 타입 코드를 서브클래스로
// abstract class Employee{
//     abstract double bonus(double sal);
// }
// class Engineer extends Employee{
//     double bonus(double s){return s*0.1;}
// }
