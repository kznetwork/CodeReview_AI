// ❌ Before — 중복 로직
class Rectangle {
    double w, h;
    double getArea()  { return w * h; }
    double getScale() { return w * h * 2; } // 중복
}

// ✅ After — Extract Method
// class Rectangle {
//     double w, h;
//     private double computeArea() {
//         return w * h; // 추출
//     }
//     double getArea()  { return computeArea(); }
//     double getScale() { return computeArea()*2;}
// }

// // ✅ Pull Up Method — 부모로 올리기
// abstract class Shape {
//     abstract double area();
//     void printArea() { // 공통 → 부모
//         System.out.println(area());
//     }
// }
// class Rect extends Shape {
//     double area() { return w * h; }
// }

// Ctrl+Shift+R → Extract Method
// 선택 영역 → Quick Fix → Extract
