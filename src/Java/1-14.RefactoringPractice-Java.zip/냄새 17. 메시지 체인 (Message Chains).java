// ❌ 냄새 17 — 메시지 체인
String name = company.getHead()
    .getDepartment()
    .getHead()
    .getName(); // 구조에 강하게 결합

// ✅ After — Hide Delegate
// class Company {
//     String getDeptHeadName() {
//         return head.getDepartment()
//                    .getHead().getName();
//     }
// }
// company.getDeptHeadName(); // 단순화

