// ❌ 냄새 13 — 고전 반복문
List<String> names = new ArrayList<>();
for(Employee e : employees)
    if("London".equals(e.office))
        names.add(e.name);

// ✅ After — Stream 파이프라인
// List<String> names = employees.stream()
//     .filter(e->"London".equals(e.office))
//     .map(e -> e.name)
//     .collect(Collectors.toList());

// Stream: filter / map / reduce
// → 무엇을 하는지 한눈에 파악
