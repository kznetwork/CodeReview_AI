// ❌ 냄새 18 — 모든 메서드가 위임만
class Person {
    Department dept;
    Manager getManager(){
        return dept.getManager(); // 위임만
    }
    int numReports(){
        return dept.numReports(); // 위임만
    }
}
// ✅ After — Remove Middle Man
// Person 제거 후 dept 직접 접근

// ✅ 서브클래스를 위임으로
// Before: class AdvPrinter extends Printer
// After:
class AdvancedPrinter {
    private Printer printer; // 위임!
    AdvancedPrinter(Printer p){printer=p;}
    void print(String msg){
        printer.print(msg); // 위임
    }
    void printWithTs(String msg){
        System.out.println(
            System.currentTimeMillis()
            + " " + msg);
    }
}
