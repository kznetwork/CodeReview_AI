// ❌ Before — 긴 함수
void processOrder(Order order){
    if(order.items.isEmpty()) return;
    if(order.customerId < 0) return;
    double total = 0;
    for(Item item : order.items)
        total += item.price * item.qty;
    double discount =
        total>100 ? total*0.1 : 0;
    total -= discount;
    new PaymentGateway()
        .charge(order.customerId, total);
    new EmailService()
        .sendConfirm(order.customerId,total);
}

// ✅ After — Extract Method
// private boolean isValid(Order o){
//     return !o.items.isEmpty()
//         && o.customerId >= 0;
// }
// private double calcTotal(Order o){
//     double t = o.items.stream()
//         .mapToDouble(i->i.price*i.qty)
//         .sum();
//     return t - (t>100 ? t*0.1 : 0);
// }
// void processOrder(Order order){
//     if(!isValid(order)) return;
//     double t = calcTotal(order);
//     new PaymentGateway().charge(
//         order.customerId, t);
// }
