// ❌ 냄새 6 — 가변
class Point { int x, y; }
Point p = new Point();
p.x = 10; // 어디서든 변경

// ✅ After 1 — 불변 값 객체
record Point(int x, int y) {}
// 불변 → 변경 시 새 객체 생성

// ✅ After 2 — 변수 쪼개기
// ❌ Before
// double tmp = 2*(h+w); // 둘레
// tmp = h * w;         // 면적 재사용
// ✅ After
double perimeter = 2*(h+w);
double area      = h * w;

// ✅ After 3 — 질의/변경 분리
int  getTotalCount() { return count; }
void increment()     { count++; }

// Java: final 필드로 불변성 보장
class Config {
    private final String url;
    Config(String url){ this.url=url;}
}
