// ❌ 냄새 12 — 반복 switch
double bonus(int type, double sal){
    switch(type){
        case 1: return sal*0.1;
        case 2: return sal*0.2;
        default: throw new ...;
    }
}
// 또 다른 곳에 동일 switch!

// ✅ After — 다형성
// abstract class Employee {
//     abstract double bonus(double sal);
//     abstract String describe();
// }
// class Engineer extends Employee {
//     double bonus(double s){return s*0.1;}
//     String describe(){return "Engineer";}
// }
