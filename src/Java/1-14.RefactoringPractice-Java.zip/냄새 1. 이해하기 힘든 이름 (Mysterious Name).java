// ❌ Before
public int calc(int x, int y) {
    return x + y;
}
class U {
    String nm;
    int ag;
}

// ✅ After
// public int calculateTotalPrice(
//     int basePrice, int tax) {
//     return basePrice + tax;
// }
// class User {
//     String name;
//     int age;
// }

// ✅ 변수 이름 바꾸기
// public void calculate() {
//     int firstNumber = 10;
//     int secondNumber = 20;
//     int result = firstNumber
//                + secondNumber;
//     System.out.println(result);
// }
// F2 → 새 이름 → Enter
// 모든 참조 일괄 변경
