// ❌ 냄새 23 — 상속 포기
class Stack extends Vector<Integer> {
    // Vector의 모든 것이 노출!
    // add, remove, indexOf 등 스택에 불필요
}

// ✅ After — 위임으로 교체
class Stack {
    private Vector<Integer> data = new Vector<>();
    void push(int val){ data.add(val); }
    int  top()        { return data.lastElement(); }
    void pop()        { data.remove(data.size()-1);}
    boolean empty()   { return data.isEmpty(); }
}

// ✅ Extract Superclass
abstract class Party {
    abstract int annualCost();
    abstract String name();
}
class Employee extends Party{
    int annualCost(){return salary;}
    String name(){return name;}
}
