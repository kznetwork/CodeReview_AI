// ❌ 냄새 7 — SRP 위반
class Order {
    void saveToDB() { ... }   // DB
    void loadFromDB() { ... }
    double discount() { ... } // 가격
    double applyTax() { ... }
}

// ✅ After — 클래스 추출
// class OrderRepository {
//     void save(Order o) { ... }
//     Order load(int id) { ... }
// }
// class PricingEngine {
//     double discount(Order o) { ... }
//     double applyTax(double p) { ... }
// }
