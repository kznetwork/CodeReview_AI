// ❌ 냄새 16 — 임시 필드
class Order {
    String customerName;
    String trackingNumber; // 온라인만
    // 매장 주문이면 null → 혼란!
}

// ✅ After — Introduce Special Case
// abstract class Order {
//     String customerName;
//     abstract boolean requiresShipping();
// }
// class OnlineOrder extends Order {
//     String trackingNumber; // 전용
//     boolean requiresShipping(){return true;}
// }
// class StoreOrder extends Order {
//     boolean requiresShipping(){return false;}
// }
