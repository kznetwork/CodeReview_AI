// ❌ 냄새 24 — 주석으로 복잡한 조건 설명
// Mac + IE + 초기화 + 크기변경
if((platform.toUpperCase().indexOf("MAC")>-1)
 &&(browser.toUpperCase().indexOf("IE")>-1)
 && wasInitialized() && resize > 0) {...}

// ✅ After — 변수 추출
boolean isMacOs =
    platform.toUpperCase().contains("MAC");
boolean isIE =
    browser.toUpperCase().contains("IE");
boolean wasResized = resize > 0;
if(isMacOs && isIE
   && wasInitialized() && wasResized){}

// ✅ Introduce Assertion
double getExpenseLimit() {
    assert expenseLimit!=NULL_EXPENSE
        || primaryProject != null;
    return expenseLimit != NULL_EXPENSE
        ? expenseLimit
        : primaryProject.getExpenseLimit();
}
