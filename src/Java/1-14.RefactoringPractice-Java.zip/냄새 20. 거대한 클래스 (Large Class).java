// ❌ 냄새 20 — 거대한 클래스
class Person {
    String name, email;
    String street, city, zip; // 주소
    String cardNumber, expiry; // 결제
    String username, password; // 인증
    void validateEmail(){}
    void processPayment(){}
    void authenticate(){}
}

// ✅ After — Extract Class
// record ContactInfo(String email){}
// record Address(String st, String city){}
// record Payment(String card, String exp){}
// class Person {
//     String name;
//     ContactInfo contact;
//     Address address;
//     Payment payment;
// }
