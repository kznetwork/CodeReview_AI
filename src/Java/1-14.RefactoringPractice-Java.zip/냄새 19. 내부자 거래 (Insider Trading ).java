// ❌ 냄새 19 — 내부자 거래
class Department {
    Employee boss; // private
}
class Payroll {
    void process(Department d) {
        // 리플렉션 등으로 직접 접근
        System.out.println(d.boss.salary);
    }
}
// ✅ After — 공개 인터페이스 제공
// class Department {
//     private Employee boss;
//     public double getBossSalary(){
//         return boss.salary;
//     }
// }
// class Payroll {
//     void process(Department d) {
//         System.out.println(
//             d.getBossSalary()); // OK
//     }
// }
