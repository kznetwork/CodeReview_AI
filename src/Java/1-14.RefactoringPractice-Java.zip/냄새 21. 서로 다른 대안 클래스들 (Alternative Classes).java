// ❌ 냄새 21 — 같은 역할, 다른 인터페이스
class EmailSender {
    void sendEmail(String to, String body){}
}
class SMSSender {
    void transmit(String num, String msg){} // 이름이 다름!
}

// ✅ After — 슈퍼클래스/인터페이스 추출
// interface Notifier {
//     void send(String recipient, String msg);
// }
// class EmailNotifier implements Notifier {
//     public void send(String to, String msg){}
// }
// class SMSNotifier implements Notifier {
//     public void send(String num, String msg){}
// }
