// ❌ 냄새 8 — 산탄총 수술
class Order  { double tax(){return p*0.1;}}
class Receipt{ double tax(){return a*0.1;}}
class Invoice{ double tax(){return t*0.1;}}
// 세율 바꾸면 3곳 모두 수정!

// ✅ After — Move Function
// class TaxCalc {
//     static final double RATE = 0.1;
//     static double calc(double amount){
//         return amount * RATE;
//     }
// }
// class Order{
//     double tax(){return TaxCalc.calc(p);}
// }
