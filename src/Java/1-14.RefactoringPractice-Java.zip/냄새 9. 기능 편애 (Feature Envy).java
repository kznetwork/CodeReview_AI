// ❌ Before — 기능 편애
class Address {
    String street, city, zipCode;
}
class Invoice {
    void printInfo(Customer c) {
        // Address 데이터를 Invoice가 직접 다룸!
        Address a = c.getAddress();
        System.out.println(
            a.getStreet() + ", " +
            a.getCity() + " " +
            a.getZipCode());
    }
}

// ✅ After — formatAddress() 이동
// class Address {
//     String street, city, zipCode;
//     // 책임을 Address로 이동
//     public String format() {
//         return street + ", " +
//                city + " " + zipCode;
//     }
// }
// class Invoice {
//     void printInfo(Customer c) {
//         // 단순 메시지 전달만
//         System.out.println(
//             c.getAddress().format());
//     }
// }
// Ctrl+. → Move Method
