// ❌ Before
void createOrder(String name,
    String address, String city,
    String zip, double price,
    int qty, String payment) {...}

// ✅ After 1: 매개변수 객체
// record Address(String street,
//     String city, String zip) {}
// record OrderInfo(String name,
//     Address addr, double price,
//     int qty, String payment) {}

// void createOrder(OrderInfo info) {...}

// ✅ After 2: 객체 통째로
// Before:
void setRange(int low, int high){}
// After:
void setRange(Range range) {
    // range.getLow() 직접 사용
}

// ✅ After 3: 질의로 교체
// Before:
// double discount(double p, double rate)
// After:
double discount(double price) {
    return price * getTaxRate();
}

// Ctrl+Shift+R →
// Introduce Parameter Object
