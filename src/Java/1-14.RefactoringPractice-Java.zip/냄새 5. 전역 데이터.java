// ❌ 냄새 5 — 전역
static int currentTemp = 0;

// ✅ After — 캡슐화
// class TemperatureManager {
//     private int temperature = 0;
//     public int  get() { return temperature; }
//     public void set(int t) { temperature=t; }
// }