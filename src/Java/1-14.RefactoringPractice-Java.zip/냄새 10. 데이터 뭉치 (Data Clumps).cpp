// ❌ 냄새 10 — 데이터 뭉치
void print(String areaCode,
    String prefix, String number){}

// ✅ After — Extract Class
// record PhoneNumber(
//     String areaCode,
//     String prefix,
//     String number) {
//     String format(){
//         return "("+areaCode+") "
//                +prefix+"-"+number;
//     }
// }
// void print(PhoneNumber p){
//     System.out.println(p.format());
// }
