// ❌ 냄새 14 — 단순한 클래스
class Multiplier {
    int multiply(int a, int b) {
        return a * b;
    }
}
// ✅ After — 인라인 / 제거
// 그냥 a * b 직접 사용
