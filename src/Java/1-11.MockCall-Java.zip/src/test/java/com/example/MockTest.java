package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MockTest {

    @Test
    void mockWithVerify() {
        // Mock + 행위 검증 (verify)
        MessageService m = mock(MessageService.class);
        when(m.sendMessage("to", "hello"))
            .thenReturn("mocked");

        String result = m.sendMessage("to", "hello");
        assertEquals("mocked", result);

        // 호출 횟수 검증
        verify(m).sendMessage("to", "hello");
        verify(m, times(1))
            .sendMessage(any(), any());
        verify(m, never())
            .sendMessage("x", "hello");

        // atLeast / atMost
        verify(m, atLeast(1))
            .sendMessage(any(), any());
        verify(m, atMost(1))
            .sendMessage(any(), any());
    }
}
