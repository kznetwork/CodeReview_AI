package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

class StubTest {

    @Test
    void stubWithWhenThenReturn() {
        // Mock 생성
        MessageService mock = mock(MessageService.class);

        // Stub (when...thenReturn)
        when(mock.sendMessage(anyString(), anyString()))
            .thenReturn("stubbed");

        // 반환값 확인
        assertEquals("stubbed",
            mock.sendMessage("to", "msg"));
    }
}
