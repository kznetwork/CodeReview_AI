package com.example;

// 메시지 서비스 인터페이스
public interface MessageService {
    String sendMessage(String to, String msg);
}
