package com.example;

public class NotificationService {
    private final MessageService messageService;

    public NotificationService(MessageService messageService) {
        this.messageService = messageService;
    }

    public String getStatus() {
        return "OK";
    }
}
