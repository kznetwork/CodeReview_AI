package com.example;

import java.util.ArrayList;
import java.util.List;

// — FAKE ——————————————————
// 실제 동작하지만 단순화된 구현
public class FakeMessageService implements MessageService {
    public List<String> messages = new ArrayList<>();

    @Override
    public String sendMessage(String to, String msg) {
        messages.add(to + ":" + msg);
        return "sent";
    }
}
