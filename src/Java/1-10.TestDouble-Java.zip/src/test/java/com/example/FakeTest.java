package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FakeTest {

    @Test
    void fakeStoresMessages() {
        var fake = new FakeMessageService();
        fake.sendMessage("alice", "hi");
        fake.sendMessage("bob", "hello");

        assertEquals(2, fake.messages.size());
        assertTrue(fake.messages.contains("alice:hi"));
    }
}
