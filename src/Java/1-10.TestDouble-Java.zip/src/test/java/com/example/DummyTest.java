package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DummyTest {

    @Test
    void dummyExample() {
        // Java — Dummy
        MessageService dummy = (to, msg) -> null;

        NotificationService svc = new NotificationService(dummy);
        assertEquals("OK", svc.getStatus());
    }
}
