public class CalcSample {
    public static int sum(int a, int b) {
        return a + b;
    }
}
