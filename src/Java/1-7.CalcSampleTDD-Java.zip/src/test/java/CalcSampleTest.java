// CalcSampleTest.java
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class CalcSampleTest {
    @Test
    void plus() {
        // Arrange & Act & Assert
        assertEquals(3, CalcSample.sum(1, 2));
        assertEquals(5, CalcSample.sum(4, 1));
        assertEquals(0, CalcSample.sum(0, 0));
        assertEquals(-5, CalcSample.sum(-3, -2));
    }

    @ParameterizedTest
    @CsvSource({"1,2,3", "4,1,5", "0,0,0", "-3,-2,-5"})
    void sum_parameterized(int a, int b, int expected) {
        assertEquals(expected, CalcSample.sum(a, b));
    }
}
