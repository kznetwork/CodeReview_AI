#pragma once
#include <string>

/**
 * 과일과 등급 검증 (null·빈 값·양수 체크)
 */
class FruitRanker {
public:
    FruitRanker(const std::string& fruit, int rank)
        : fruit_(fruit), rank_(rank) {}

    const std::string& getFruit() const { return fruit_; }
    int getRank() const { return rank_; }

    bool isValid() const {
        return !fruit_.empty() && rank_ > 0;
    }

private:
    std::string fruit_;
    int rank_;
};
