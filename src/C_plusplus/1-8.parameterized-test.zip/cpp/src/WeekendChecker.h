#pragma once
#include "DayOfWeek.h"

/**
 * 주어진 요일이 주말(SATURDAY, SUNDAY)인지 판별
 */
class WeekendChecker {
public:
    static bool isWeekend(DayOfWeek day) {
        return day == DayOfWeek::SATURDAY || day == DayOfWeek::SUNDAY;
    }
};
