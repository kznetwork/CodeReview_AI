#pragma once

/**
 * 요일 Enum (MONDAY ~ SUNDAY)
 */
enum class DayOfWeek {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY
};
