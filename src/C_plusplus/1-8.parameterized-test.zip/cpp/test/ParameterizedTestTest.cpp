#include <gtest/gtest.h>
#include <string>
#include <tuple>
#include "DayOfWeek.h"
#include "WeekendChecker.h"
#include "FruitRanker.h"

// ──────────────────────────────────────────────
// 1. 문자열 목록 — Values (Java의 @ValueSource 대응)
// ──────────────────────────────────────────────
class NameTest : public ::testing::TestWithParam<std::string> {};

TEST_P(NameTest, PrintName) {
    std::string name = GetParam();
    EXPECT_FALSE(name.empty());
}

INSTANTIATE_TEST_SUITE_P(
    ValueSourceLike,
    NameTest,
    ::testing::Values("hong", "kim", "park")
);

// ──────────────────────────────────────────────
// 2. Enum 전체 — Values (Java의 @EnumSource 대응)
// ──────────────────────────────────────────────
class DayOfWeekAllTest : public ::testing::TestWithParam<DayOfWeek> {};

TEST_P(DayOfWeekAllTest, PrintDayOfWeek) {
    DayOfWeek day = GetParam();
    // enum class 값이므로 항상 유효
    SUCCEED();
}

INSTANTIATE_TEST_SUITE_P(
    EnumSourceAll,
    DayOfWeekAllTest,
    ::testing::Values(
        DayOfWeek::MONDAY,
        DayOfWeek::TUESDAY,
        DayOfWeek::WEDNESDAY,
        DayOfWeek::THURSDAY,
        DayOfWeek::FRIDAY,
        DayOfWeek::SATURDAY,
        DayOfWeek::SUNDAY
    )
);

// ──────────────────────────────────────────────
// 3. Enum 선택 — names 필터 (평일만)
// ──────────────────────────────────────────────
class WeekdayFilterTest : public ::testing::TestWithParam<DayOfWeek> {};

TEST_P(WeekdayFilterTest, IsNotWeekend) {
    DayOfWeek day = GetParam();
    EXPECT_FALSE(WeekendChecker::isWeekend(day));
}

INSTANTIATE_TEST_SUITE_P(
    EnumSourceFiltered,
    WeekdayFilterTest,
    ::testing::Values(
        DayOfWeek::MONDAY,
        DayOfWeek::WEDNESDAY,
        DayOfWeek::FRIDAY
    )
);

// ──────────────────────────────────────────────
// 4. CSV 다중 입력 — tuple (Java의 @CsvSource 대응)
// ──────────────────────────────────────────────
class CsvSourceTest : public ::testing::TestWithParam<std::tuple<std::string, int>> {};

TEST_P(CsvSourceTest, TestWithCsvSource) {
    auto [fruit, rank] = GetParam();
    EXPECT_FALSE(fruit.empty());
    EXPECT_GT(rank, 0);
}

INSTANTIATE_TEST_SUITE_P(
    CsvSourceLike,
    CsvSourceTest,
    ::testing::Values(
        std::make_tuple("apple", 1),
        std::make_tuple("banana", 2),
        std::make_tuple("lemon, lime", 3)
    )
);

// ──────────────────────────────────────────────
// 5. 주말 판별 — 성공/실패 혼합
//    MONDAY 포함 → 의도적 실패 (TDD 학습용)
// ──────────────────────────────────────────────
class WeekendMixedTest : public ::testing::TestWithParam<DayOfWeek> {};

TEST_P(WeekendMixedTest, TestIsWeekend) {
    DayOfWeek day = GetParam();
    // ⚠ MONDAY가 포함돼 테스트 실패 → 의도된 것
    // → WeekendChecker 로직 점검 기회
    EXPECT_TRUE(WeekendChecker::isWeekend(day));
}

INSTANTIATE_TEST_SUITE_P(
    WeekendWithIntentionalFailure,
    WeekendMixedTest,
    ::testing::Values(
        DayOfWeek::SATURDAY,
        DayOfWeek::MONDAY,   // ⚠ 의도적 실패
        DayOfWeek::SUNDAY
    )
);
