#include "NotificationService.h"

NotificationService::NotificationService(MessageService* svc)
    : messageService_(svc), status_("OK") {}

std::string NotificationService::getStatus() const {
    return status_;
}
