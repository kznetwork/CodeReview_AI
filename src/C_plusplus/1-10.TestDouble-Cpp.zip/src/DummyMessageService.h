#pragma once
#include "MessageService.h"

// — DUMMY ——————————————————
// 인터페이스 충족용, 실제로 호출 안 됨
class DummyMessageService : public MessageService {
public:
    std::string sendMessage(
        const std::string&,
        const std::string&) override {
        return "";  // 아무 일도 안 함
    }
};
