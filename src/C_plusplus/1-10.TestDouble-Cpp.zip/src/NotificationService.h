#pragma once
#include <string>
#include "MessageService.h"

class NotificationService {
    MessageService* messageService_;
    std::string status_;
public:
    explicit NotificationService(MessageService* svc);
    std::string getStatus() const;
};
