#pragma once
#include "MessageService.h"
#include <vector>
#include <string>

// — FAKE ——————————————————
// 실제 동작하지만 단순화된 구현
class FakeMessageService : public MessageService {
    std::vector<std::string> messages_;
public:
    std::string sendMessage(
        const std::string& to,
        const std::string& msg) override {
        messages_.push_back(to + ":" + msg);
        return "sent";
    }

    const std::vector<std::string>& getMessages() const { return messages_; }
};
