#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "FakeMessageService.h"

using ::testing::Contains;

TEST(FakeTest, StoresMessages) {
    FakeMessageService fake;
    fake.sendMessage("alice", "hi");
    fake.sendMessage("bob",   "hello");

    EXPECT_EQ(2u, fake.getMessages().size());
    EXPECT_THAT(fake.getMessages(),
        Contains("alice:hi"));
}
