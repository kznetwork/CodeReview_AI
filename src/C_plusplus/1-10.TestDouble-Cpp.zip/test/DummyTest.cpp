#include <gtest/gtest.h>
#include "DummyMessageService.h"
#include "NotificationService.h"

TEST(NotificationTest, DummyExample) {
    DummyMessageService dummy;
    NotificationService svc(&dummy);
    // sendMessage는 실제 호출 안 됨
    EXPECT_EQ("OK", svc.getStatus());
}
