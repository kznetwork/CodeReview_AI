# Employee Management System (C++)

Java 프로젝트를 C++17로 포팅한 사원 관리 시스템입니다.

## 빌드 방법

```bash
mkdir build
cd build
cmake ..
cmake --build .
```

## 실행 방법

```bash
./EmployeeManagement input.txt output.txt
```

## 프로젝트 구조

```
include/                    # 헤더 파일
├── command/                # 명령어 클래스 (Command, Add, Del, Sch, Mod, Count)
├── field/                  # 필드 클래스 (Field, Name, Birthday, CareerLevel, PhoneNumber, EmployeeNumber, Certi)
├── store/                  # 저장소 (Employee, EmployeeStore, EmployeeStoreImpl, FieldEnum)
├── util/                   # 유틸리티 (OptionParser, Pair, ResultStringFormatter)
├── CommandExecutor.h
├── CommandFactory.h
├── CommandParser.h
├── CommandReader.h
├── Printer.h
└── TokenGroup.h

src/                        # 소스 파일
├── command/
├── field/
├── store/
├── util/
├── main.cpp
├── CommandExecutor.cpp
├── CommandFactory.cpp
├── CommandParser.cpp
├── CommandReader.cpp
├── Printer.cpp
└── TokenGroup.cpp
```

## 지원 명령어

| 명령어 | 설명 |
|--------|------|
| ADD | 사원 추가 |
| DEL | 사원 삭제 |
| SCH | 사원 검색 |
| MOD | 사원 수정 |
| CNT | 사원 수 조회 |

## 옵션

- **옵션1 (-p)**: 출력 옵션 (최대 5개 레코드 출력)
- **옵션2**: 필드 세부 선택 (-f, -l, -m, -y, -d)
- **옵션3**: 부등호 비교 (-g, -ge, -s, -se) - SCH 전용
- **AND/OR**: 다중 조건 검색 (-a, -o)

## 요구사항

- C++17 이상
- CMake 3.14 이상
