#include "store/Employee.h"

Employee::Employee(const std::string& employeeNumber,
                   const std::string& name,
                   const std::string& careerLevel,
                   const std::string& phoneNumber,
                   const std::string& birthday,
                   const std::string& certi)
    : employeeNumber_(employeeNumber)
    , name_(name)
    , careerLevel_(careerLevel)
    , phoneNumber_(phoneNumber)
    , birthday_(birthday)
    , certi_(certi) {}

Employee::Employee(const Employee& other)
    : employeeNumber_(other.employeeNumber_.toString())
    , name_(other.name_.toString())
    , careerLevel_(other.careerLevel_.toString())
    , phoneNumber_(other.phoneNumber_.toString())
    , birthday_(other.birthday_.toString())
    , certi_(other.certi_.toString()) {}

Employee& Employee::operator=(const Employee& other) {
    if (this != &other) {
        employeeNumber_ = EmployeeNumber(other.employeeNumber_.toString());
        name_ = Name(other.name_.toString());
        careerLevel_ = CareerLevel(other.careerLevel_.toString());
        phoneNumber_ = PhoneNumber(other.phoneNumber_.toString());
        birthday_ = Birthday(other.birthday_.toString());
        certi_ = Certi(other.certi_.toString());
    }
    return *this;
}

bool Employee::operator==(const Employee& other) const {
    return employeeNumber_.toString() == other.employeeNumber_.toString();
}
