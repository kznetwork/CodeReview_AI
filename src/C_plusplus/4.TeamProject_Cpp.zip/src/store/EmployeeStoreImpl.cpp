#include "store/EmployeeStoreImpl.h"
#include <algorithm>
#include <stdexcept>

EmployeeStoreImpl::EmployeeStoreImpl() {
    initializeFieldMaps();
}

void EmployeeStoreImpl::initializeFieldMaps() {
    fieldCreators_[FieldEnum::FIELD_EMPLOYEE_NUMBER] = [](const std::string& v) { return std::make_unique<EmployeeNumber>(v); };
    fieldCreators_[FieldEnum::FIELD_NAME] = [](const std::string& v) { return std::make_unique<Name>(v); };
    fieldCreators_[FieldEnum::FIELD_CAREER_LEVEL] = [](const std::string& v) { return std::make_unique<CareerLevel>(v); };
    fieldCreators_[FieldEnum::FIELD_PHONE_NUMBER] = [](const std::string& v) { return std::make_unique<PhoneNumber>(v); };
    fieldCreators_[FieldEnum::FIELD_BIRTH_DAY] = [](const std::string& v) { return std::make_unique<Birthday>(v); };
    fieldCreators_[FieldEnum::FIELD_CERTI] = [](const std::string& v) { return std::make_unique<Certi>(v); };

    fieldExtractors_[FieldEnum::FIELD_EMPLOYEE_NUMBER] = [](const Employee& e) -> const Field& { return e.getEmployeeNumber(); };
    fieldExtractors_[FieldEnum::FIELD_NAME] = [](const Employee& e) -> const Field& { return e.getName(); };
    fieldExtractors_[FieldEnum::FIELD_CAREER_LEVEL] = [](const Employee& e) -> const Field& { return e.getCareerLevel(); };
    fieldExtractors_[FieldEnum::FIELD_PHONE_NUMBER] = [](const Employee& e) -> const Field& { return e.getPhoneNumber(); };
    fieldExtractors_[FieldEnum::FIELD_BIRTH_DAY] = [](const Employee& e) -> const Field& { return e.getBirthday(); };
    fieldExtractors_[FieldEnum::FIELD_CERTI] = [](const Employee& e) -> const Field& { return e.getCerti(); };
}

void EmployeeStoreImpl::add(const Employee& employee) {
    employees_.push_back(employee);
}

int EmployeeStoreImpl::count() const {
    return static_cast<int>(employees_.size());
}

std::vector<Employee> EmployeeStoreImpl::search(FieldEnum field, const std::string& value,
                                                 TertiaryOptionEnum tertiaryOption) {
    return search(field, value, tertiaryOption, 0);
}

std::vector<Employee> EmployeeStoreImpl::search(FieldEnum field, const std::string& value,
                                                 TertiaryOptionEnum tertiaryOption, int subfieldIndex) {
    auto creatorIt = fieldCreators_.find(field);
    auto extractorIt = fieldExtractors_.find(field);
    if (creatorIt == fieldCreators_.end() || extractorIt == fieldExtractors_.end()) {
        return {};
    }

    auto searchField = creatorIt->second(value);
    std::vector<Employee> result;
    for (const auto& emp : employees_) {
        const Field& targetField = extractorIt->second(emp);
        if (targetField.compare(*searchField, subfieldIndex, tertiaryOption)) {
            result.push_back(emp);
        }
    }
    return result;
}

std::vector<Employee> EmployeeStoreImpl::search(FieldEnum field1, const std::string& value1,
                                                 TertiaryOptionEnum tertiary1, int subfieldIndex1,
                                                 CombinationEnum combination,
                                                 FieldEnum field2, const std::string& value2,
                                                 TertiaryOptionEnum tertiary2, int subfieldIndex2) {
    auto searchField1 = fieldCreators_[field1](value1);
    auto searchField2 = fieldCreators_[field2](value2);

    std::vector<Employee> result;
    for (const auto& emp : employees_) {
        const Field& target1 = fieldExtractors_[field1](emp);
        const Field& target2 = fieldExtractors_[field2](emp);
        bool match1 = target1.compare(*searchField1, subfieldIndex1, tertiary1);
        bool match2 = target2.compare(*searchField2, subfieldIndex2, tertiary2);

        if (combination == CombinationEnum::OR) {
            if (match1 || match2) result.push_back(emp);
        } else {
            if (match1 && match2) result.push_back(emp);
        }
    }
    return result;
}

std::vector<Employee> EmployeeStoreImpl::del(FieldEnum field, const std::string& value) {
    return del(field, value, 0);
}

std::vector<Employee> EmployeeStoreImpl::del(FieldEnum field, const std::string& value, int subfieldIndex) {
    auto searched = search(field, value, TertiaryOptionEnum::NONE, subfieldIndex);
    employees_.erase(
        std::remove_if(employees_.begin(), employees_.end(),
            [&searched](const Employee& e) {
                return std::find(searched.begin(), searched.end(), e) != searched.end();
            }),
        employees_.end());
    return searched;
}

std::vector<Employee> EmployeeStoreImpl::del(FieldEnum field, const std::string& value, int subfieldIndex,
                                              CombinationEnum combination,
                                              FieldEnum field2, const std::string& value2, int subfieldIndex2) {
    auto searched = search(field, value, TertiaryOptionEnum::NONE, subfieldIndex,
                           combination, field2, value2, TertiaryOptionEnum::NONE, subfieldIndex2);
    employees_.erase(
        std::remove_if(employees_.begin(), employees_.end(),
            [&searched](const Employee& e) {
                return std::find(searched.begin(), searched.end(), e) != searched.end();
            }),
        employees_.end());
    return searched;
}

std::vector<Employee> EmployeeStoreImpl::modify(FieldEnum field, const std::string& value,
                                                 FieldEnum modifyField, const std::string& modifyValue) {
    return modify(field, value, modifyField, modifyValue, 0);
}

std::vector<Employee> EmployeeStoreImpl::modify(FieldEnum field, const std::string& value,
                                                 FieldEnum modifyField, const std::string& modifyValue,
                                                 int subfieldIndex) {
    if (modifyField == FieldEnum::FIELD_EMPLOYEE_NUMBER) {
        throw std::invalid_argument("Employee number cannot be modified");
    }

    auto searched = search(field, value, TertiaryOptionEnum::NONE, subfieldIndex);

    employees_.erase(
        std::remove_if(employees_.begin(), employees_.end(),
            [&searched](const Employee& e) {
                return std::find(searched.begin(), searched.end(), e) != searched.end();
            }),
        employees_.end());

    auto modified = modifyFieldOfList(modifyField, modifyValue, searched);
    for (const auto& emp : modified) {
        employees_.push_back(emp);
    }

    return searched;
}

std::vector<Employee> EmployeeStoreImpl::modify(FieldEnum field, const std::string& value, int subfieldIndex,
                                                 CombinationEnum combination,
                                                 FieldEnum field2, const std::string& value2, int subfieldIndex2,
                                                 FieldEnum modifyField, const std::string& modifyValue) {
    if (modifyField == FieldEnum::FIELD_EMPLOYEE_NUMBER) {
        throw std::invalid_argument("Employee number cannot be modified");
    }

    auto searched = search(field, value, TertiaryOptionEnum::NONE, subfieldIndex,
                           combination, field2, value2, TertiaryOptionEnum::NONE, subfieldIndex2);

    employees_.erase(
        std::remove_if(employees_.begin(), employees_.end(),
            [&searched](const Employee& e) {
                return std::find(searched.begin(), searched.end(), e) != searched.end();
            }),
        employees_.end());

    auto modified = modifyFieldOfList(modifyField, modifyValue, searched);
    for (const auto& emp : modified) {
        employees_.push_back(emp);
    }

    return searched;
}

std::vector<Employee> EmployeeStoreImpl::modifyFieldOfList(FieldEnum modifyField, const std::string& modifyValue,
                                                            const std::vector<Employee>& employees) {
    std::vector<Employee> result;
    for (const auto& emp : employees) {
        Employee copy(emp);
        switch (modifyField) {
            case FieldEnum::FIELD_EMPLOYEE_NUMBER:
                copy.setEmployeeNumber(EmployeeNumber(modifyValue)); break;
            case FieldEnum::FIELD_NAME:
                copy.setName(Name(modifyValue)); break;
            case FieldEnum::FIELD_CAREER_LEVEL:
                copy.setCareerLevel(CareerLevel(modifyValue)); break;
            case FieldEnum::FIELD_PHONE_NUMBER:
                copy.setPhoneNumber(PhoneNumber(modifyValue)); break;
            case FieldEnum::FIELD_BIRTH_DAY:
                copy.setBirthday(Birthday(modifyValue)); break;
            case FieldEnum::FIELD_CERTI:
                copy.setCerti(Certi(modifyValue)); break;
            default:
                break;
        }
        result.push_back(copy);
    }
    return result;
}
