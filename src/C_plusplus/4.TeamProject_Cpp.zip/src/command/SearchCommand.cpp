#include "command/SearchCommand.h"
#include "CommandFactory.h"
#include "CommandExecutor.h"
#include "util/ResultStringFormatter.h"

SearchCommand::SearchCommand(std::shared_ptr<OptionParser> optionParser,
                             Pair<std::string, std::string> conditionPair)
    : Command(optionParser, conditionPair) {}

SearchCommand::SearchCommand(std::shared_ptr<OptionParser> firstOptionParser,
                             Pair<std::string, std::string> firstConditionPair,
                             CombinationEnum combinationEnum,
                             std::shared_ptr<OptionParser> secondOptionParser,
                             Pair<std::string, std::string> secondConditionPair)
    : Command(firstOptionParser, firstConditionPair, combinationEnum, secondOptionParser, secondConditionPair) {}

std::vector<std::string> SearchCommand::executeSingle(EmployeeStore& employeeStore) {
    FieldEnum fieldCondition = fieldEnumFromString(firstConditionPair_.first);
    int fieldIndex = getFieldIndexFromOption(*firstOptionParser_, fieldCondition);
    TertiaryOptionEnum tertiaryOption = firstOptionParser_->getTertiaryOption();

    auto employeeList = employeeStore.search(fieldCondition, firstConditionPair_.second, tertiaryOption, fieldIndex);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_SCH, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_SCH);
}

std::vector<std::string> SearchCommand::executeAndOr(EmployeeStore& employeeStore) {
    FieldEnum firstFieldCondition = fieldEnumFromString(firstConditionPair_.first);
    FieldEnum secondFieldCondition = fieldEnumFromString(secondConditionPair_.first);

    int firstFieldIndex = getFieldIndexFromOption(*firstOptionParser_, firstFieldCondition);
    int secondFieldIndex = getFieldIndexFromOption(*secondOptionParser_, secondFieldCondition);
    TertiaryOptionEnum firstTertiary = firstOptionParser_->getTertiaryOption();
    TertiaryOptionEnum secondTertiary = secondOptionParser_->getTertiaryOption();

    auto employeeList = employeeStore.search(firstFieldCondition, firstConditionPair_.second, firstTertiary, firstFieldIndex,
                                              combinationEnum_,
                                              secondFieldCondition, secondConditionPair_.second, secondTertiary, secondFieldIndex);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_SCH, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_SCH);
}
