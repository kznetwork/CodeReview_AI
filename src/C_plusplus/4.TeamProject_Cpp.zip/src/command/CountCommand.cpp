#include "command/CountCommand.h"
#include "CommandFactory.h"

std::vector<std::string> CountCommand::execute(EmployeeStore& employeeStore) {
    return { std::string(CommandFactory::CMD_CNT) + "," + std::to_string(employeeStore.count()) };
}
