#include "command/DeleteCommand.h"
#include "CommandFactory.h"
#include "CommandExecutor.h"
#include "util/ResultStringFormatter.h"

DeleteCommand::DeleteCommand(std::shared_ptr<OptionParser> optionParser,
                             Pair<std::string, std::string> conditionPair)
    : Command(optionParser, conditionPair) {}

DeleteCommand::DeleteCommand(std::shared_ptr<OptionParser> firstOptionParser,
                             Pair<std::string, std::string> firstConditionPair,
                             CombinationEnum combinationEnum,
                             std::shared_ptr<OptionParser> secondOptionParser,
                             Pair<std::string, std::string> secondConditionPair)
    : Command(firstOptionParser, firstConditionPair, combinationEnum, secondOptionParser, secondConditionPair) {}

std::vector<std::string> DeleteCommand::executeSingle(EmployeeStore& employeeStore) {
    FieldEnum fieldCondition = fieldEnumFromString(firstConditionPair_.first);
    int fieldIndex = getFieldIndexFromOption(*firstOptionParser_, fieldCondition);

    auto employeeList = employeeStore.del(fieldCondition, firstConditionPair_.second, fieldIndex);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_DEL, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_DEL);
}

std::vector<std::string> DeleteCommand::executeAndOr(EmployeeStore& employeeStore) {
    FieldEnum firstFieldCondition = fieldEnumFromString(firstConditionPair_.first);
    FieldEnum secondFieldCondition = fieldEnumFromString(secondConditionPair_.first);

    int firstFieldIndex = getFieldIndexFromOption(*firstOptionParser_, firstFieldCondition);
    int secondFieldIndex = getFieldIndexFromOption(*secondOptionParser_, secondFieldCondition);

    auto employeeList = employeeStore.del(firstFieldCondition, firstConditionPair_.second, firstFieldIndex,
                                           combinationEnum_,
                                           secondFieldCondition, secondConditionPair_.second, secondFieldIndex);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_DEL, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_DEL);
}
