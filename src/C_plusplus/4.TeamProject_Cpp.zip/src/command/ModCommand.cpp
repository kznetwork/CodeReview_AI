#include "command/ModCommand.h"
#include "CommandFactory.h"
#include "CommandExecutor.h"
#include "util/ResultStringFormatter.h"

ModCommand::ModCommand(std::shared_ptr<OptionParser> optionParser,
                       Pair<std::string, std::string> conditionPair,
                       Pair<std::string, std::string> conditionModifyPair)
    : Command(optionParser, conditionPair), conditionModifyPair_(conditionModifyPair) {}

ModCommand::ModCommand(std::shared_ptr<OptionParser> firstOptionParser,
                       Pair<std::string, std::string> firstConditionPair,
                       CombinationEnum combinationEnum,
                       std::shared_ptr<OptionParser> secondOptionParser,
                       Pair<std::string, std::string> secondConditionPair,
                       Pair<std::string, std::string> conditionModifyPair)
    : Command(firstOptionParser, firstConditionPair, combinationEnum, secondOptionParser, secondConditionPair)
    , conditionModifyPair_(conditionModifyPair) {}

std::vector<std::string> ModCommand::executeSingle(EmployeeStore& employeeStore) {
    FieldEnum fieldCondition = fieldEnumFromString(firstConditionPair_.first);
    FieldEnum fieldModifyCondition = fieldEnumFromString(conditionModifyPair_.first);
    int fieldIndex = getFieldIndexFromOption(*firstOptionParser_, fieldCondition);

    auto employeeList = employeeStore.modify(fieldCondition, firstConditionPair_.second,
                                              fieldModifyCondition, conditionModifyPair_.second, fieldIndex);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_MOD, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_MOD);
}

std::vector<std::string> ModCommand::executeAndOr(EmployeeStore& employeeStore) {
    FieldEnum firstFieldCondition = fieldEnumFromString(firstConditionPair_.first);
    FieldEnum secondFieldCondition = fieldEnumFromString(secondConditionPair_.first);
    FieldEnum fieldModifyCondition = fieldEnumFromString(conditionModifyPair_.first);

    int firstFieldIndex = getFieldIndexFromOption(*firstOptionParser_, firstFieldCondition);
    int secondFieldIndex = getFieldIndexFromOption(*secondOptionParser_, secondFieldCondition);

    auto employeeList = employeeStore.modify(firstFieldCondition, firstConditionPair_.second, firstFieldIndex,
                                              combinationEnum_,
                                              secondFieldCondition, secondConditionPair_.second, secondFieldIndex,
                                              fieldModifyCondition, conditionModifyPair_.second);

    if (firstOptionParser_->getPrimaryOption() == PrimaryOptionEnum::PRINT) {
        return ResultStringFormatter::getEmployeeListToFormattedString(
            employeeList, CommandFactory::CMD_MOD, CommandExecutor::MAX_RESULT_NUMBER);
    }
    return ResultStringFormatter::getEmployeeListToFormattedString(employeeList, CommandFactory::CMD_MOD);
}
