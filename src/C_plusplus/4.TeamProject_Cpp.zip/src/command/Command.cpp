#include "command/Command.h"

Command::Command(std::shared_ptr<OptionParser> firstOptionParser,
                 Pair<std::string, std::string> firstConditionPair)
    : firstOptionParser_(firstOptionParser)
    , firstConditionPair_(firstConditionPair)
    , combinationEnum_(CombinationEnum::NONE)
    , secondOptionParser_(std::make_shared<OptionParser>(std::vector<std::string>{" ", " "}))
    , secondConditionPair_(Pair<std::string, std::string>::create(" ", " ")) {}

Command::Command(std::shared_ptr<OptionParser> firstOptionParser,
                 Pair<std::string, std::string> firstConditionPair,
                 CombinationEnum combinationEnum,
                 std::shared_ptr<OptionParser> secondOptionParser,
                 Pair<std::string, std::string> secondConditionPair)
    : firstOptionParser_(firstOptionParser)
    , firstConditionPair_(firstConditionPair)
    , combinationEnum_(combinationEnum)
    , secondOptionParser_(secondOptionParser)
    , secondConditionPair_(secondConditionPair) {}

std::vector<std::string> Command::execute(EmployeeStore& employeeStore) {
    if (combinationEnum_ == CombinationEnum::AND || combinationEnum_ == CombinationEnum::OR) {
        return executeAndOr(employeeStore);
    }
    return executeSingle(employeeStore);
}

std::vector<std::string> Command::executeSingle(EmployeeStore& /*employeeStore*/) {
    return {};
}

std::vector<std::string> Command::executeAndOr(EmployeeStore& /*employeeStore*/) {
    return {};
}
