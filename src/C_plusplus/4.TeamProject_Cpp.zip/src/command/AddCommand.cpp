#include "command/AddCommand.h"

AddCommand::AddCommand(std::shared_ptr<OptionParser> optionParser, const Employee& employee)
    : employee_(employee), optionParser_(optionParser) {}

std::vector<std::string> AddCommand::execute(EmployeeStore& employeeStore) {
    employeeStore.add(employee_);
    return {};
}
