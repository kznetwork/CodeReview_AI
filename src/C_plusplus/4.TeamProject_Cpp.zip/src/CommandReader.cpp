#include "CommandReader.h"
#include <fstream>
#include <stdexcept>

CommandReader::CommandReader(const std::string& inputFileName)
    : inputFileName_(inputFileName) {}

std::vector<std::string> CommandReader::readFile() const {
    std::vector<std::string> lines;
    std::ifstream file(inputFileName_);
    if (!file.is_open()) {
        throw std::invalid_argument("Input file " + inputFileName_ + " does NOT exist");
    }
    std::string line;
    while (std::getline(file, line)) {
        lines.push_back(line);
    }
    return lines;
}
