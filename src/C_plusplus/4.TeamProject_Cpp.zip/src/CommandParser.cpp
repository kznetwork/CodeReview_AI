#include "CommandParser.h"
#include <sstream>

TokenGroup CommandParser::parse(const std::string& line) const {
    // Split by ','
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream ss(line);
    while (std::getline(ss, token, ',')) {
        tokens.push_back(token);
    }

    std::string type = tokens[0];
    std::vector<std::string> options(tokens.begin() + 1, tokens.begin() + 4);
    std::vector<std::string> params(tokens.begin() + 4, tokens.end());

    // Check for AND/OR condition
    int conditionIdx = getConditionIndex(params);
    if (conditionIdx != -1) {
        std::string condition = params[conditionIdx];
        std::vector<std::string> firstParams(params.begin(), params.begin() + conditionIdx);
        std::vector<std::string> secondOptions;
        secondOptions.push_back(" ");
        secondOptions.push_back(params[conditionIdx + 1]);
        secondOptions.push_back(params[conditionIdx + 2]);
        std::vector<std::string> secondParams(params.begin() + conditionIdx + 3, tokens.end() - 4);

        return TokenGroup(
            type,
            getValidList(options), getValidList(firstParams),
            condition,
            getValidList(secondOptions), getValidList(secondParams)
        );
    }

    return TokenGroup(type, getValidList(options), getValidList(params));
}

int CommandParser::getConditionIndex(const std::vector<std::string>& params) {
    for (int i = 0; i < static_cast<int>(params.size()); ++i) {
        if (params[i] == "-a" || params[i] == "-o") {
            return i;
        }
    }
    return -1;
}

std::vector<std::string> CommandParser::getValidList(const std::vector<std::string>& list) {
    std::vector<std::string> validList;
    for (const auto& item : list) {
        if (!item.empty()) {
            validList.push_back(item);
        }
    }
    return validList;
}
