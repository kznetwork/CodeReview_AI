#include "CommandFactory.h"
#include "command/AddCommand.h"
#include "command/DeleteCommand.h"
#include "command/SearchCommand.h"
#include "command/ModCommand.h"
#include "command/CountCommand.h"
#include "store/Employee.h"
#include "store/EmployeeStore.h"
#include <stdexcept>

const std::map<std::string, std::string>& CommandFactory::getFieldMap() {
    static const std::map<std::string, std::string> fieldMap = {
        {"employeeNum", EmployeeStore::FIELD_EMPLOYEE_NUMBER},
        {"name", EmployeeStore::FIELD_NAME},
        {"cl", EmployeeStore::FIELD_CAREER_LEVEL},
        {"phoneNum", EmployeeStore::FIELD_PHONE_NUMBER},
        {"birthday", EmployeeStore::FIELD_BIRTH_DAY},
        {"certi", EmployeeStore::FIELD_CERTI}
    };
    return fieldMap;
}

std::unique_ptr<Command> CommandFactory::buildCommand(const TokenGroup& tokens) const {
    if (tokens.getCombinationEnum() == CombinationEnum::NONE) {
        return buildSingleCommand(tokens.getType(), tokens.getOptions(), tokens.getParams());
    }
    return buildAndOrCommand(tokens);
}

std::unique_ptr<Command> CommandFactory::buildSingleCommand(const std::string& cmd,
                                                             const std::vector<std::string>& options,
                                                             const std::vector<std::string>& params) {
    auto optionParser = std::make_shared<OptionParser>(options);

    if (cmd == CMD_ADD) {
        Employee employee(params[0], params[1], params[2], params[3], params[4], params[5]);
        return std::make_unique<AddCommand>(optionParser, employee);
    }
    if (cmd == CMD_DEL) {
        return std::make_unique<DeleteCommand>(optionParser, getConditionMapFromParams(params, *optionParser));
    }
    if (cmd == CMD_MOD) {
        return std::make_unique<ModCommand>(optionParser,
            getConditionMapFromParams(params, *optionParser),
            getConditionMapFromModifyParams(params, *optionParser));
    }
    if (cmd == CMD_SCH) {
        return std::make_unique<SearchCommand>(optionParser, getConditionMapFromParams(params, *optionParser));
    }
    if (cmd == CMD_CNT) {
        return std::make_unique<CountCommand>();
    }
    throw std::invalid_argument("Wrong command: " + cmd);
}

std::unique_ptr<Command> CommandFactory::buildAndOrCommand(const TokenGroup& tokens) {
    std::string cmd = tokens.getType();
    const auto& firstParams = tokens.getFirstParams();
    const auto& secondParams = tokens.getSecondParams();
    CombinationEnum combination = tokens.getCombinationEnum();
    const auto& firstOptions = tokens.getFirstOptions();
    const auto& secondOptions = tokens.getSecondOptions();

    auto firstOptionParser = std::make_shared<OptionParser>(firstOptions);
    auto secondOptionParser = std::make_shared<OptionParser>(secondOptions);

    if (cmd == CMD_ADD) {
        throw std::invalid_argument("And Or Line must not have ADD.");
    }
    if (cmd == CMD_DEL) {
        return std::make_unique<DeleteCommand>(
            firstOptionParser, getConditionMapFromParams(firstParams, *firstOptionParser),
            combination,
            secondOptionParser, getConditionMapFromParams(secondParams, *secondOptionParser));
    }
    if (cmd == CMD_MOD) {
        return std::make_unique<ModCommand>(
            firstOptionParser, getConditionMapFromParams(firstParams, *firstOptionParser),
            combination,
            secondOptionParser, getConditionMapFromParams(secondParams, *secondOptionParser),
            getConditionMapFromModifyParams(secondParams, *secondOptionParser));
    }
    if (cmd == CMD_SCH) {
        return std::make_unique<SearchCommand>(
            firstOptionParser, getConditionMapFromParams(firstParams, *firstOptionParser),
            combination,
            secondOptionParser, getConditionMapFromParams(secondParams, *secondOptionParser));
    }
    if (cmd == CMD_CNT) {
        return std::make_unique<CountCommand>();
    }
    throw std::invalid_argument("Wrong command: " + cmd);
}

Pair<std::string, std::string> CommandFactory::getConditionMapFromParams(
    const std::vector<std::string>& params, const OptionParser& optionParser) {

    const auto& fieldMap = getFieldMap();
    auto it = fieldMap.find(params[0]);
    if (it == fieldMap.end()) {
        throw std::invalid_argument("Wrong field: " + params[0]);
    }
    const std::string& fieldName = it->second;
    int secType = getSecondaryOptionType(optionParser.getSecondaryOption());

    if (secType == 1) {
        return Pair<std::string, std::string>::create(fieldName, params[1] + " KIM");
    }
    if (secType == 2) {
        if (fieldName == "name")
            return Pair<std::string, std::string>::create(fieldName, "HOHAN " + params[1]);
        if (fieldName == "phoneNumber")
            return Pair<std::string, std::string>::create(fieldName, "010-0000-" + params[1]);
    }
    if (secType == 3) {
        if (fieldName == "birthDay")
            return Pair<std::string, std::string>::create(fieldName, "9999" + params[1] + "99");
        if (fieldName == "phoneNumber")
            return Pair<std::string, std::string>::create(fieldName, "010-" + params[1] + "-0000");
    }
    if (secType == 4) {
        return Pair<std::string, std::string>::create(fieldName, params[1] + "9999");
    }
    if (secType == 5) {
        return Pair<std::string, std::string>::create(fieldName, "999999" + params[1]);
    }

    return Pair<std::string, std::string>::create(fieldName, params[1]);
}

Pair<std::string, std::string> CommandFactory::getConditionMapFromModifyParams(
    const std::vector<std::string>& params, const OptionParser& optionParser) {

    const auto& fieldMap = getFieldMap();
    auto it = fieldMap.find(params[2]);
    if (it == fieldMap.end() || it->second == EmployeeStore::FIELD_EMPLOYEE_NUMBER) {
        throw std::invalid_argument("Wrong field: " + params[2]);
    }
    return Pair<std::string, std::string>::create(it->second, params[3]);
}

std::string CommandFactory::getFieldMapParam(const std::string& param) {
    const auto& fieldMap = getFieldMap();
    auto it = fieldMap.find(param);
    if (it == fieldMap.end()) {
        throw std::invalid_argument("Wrong field: " + param);
    }
    return it->second;
}
