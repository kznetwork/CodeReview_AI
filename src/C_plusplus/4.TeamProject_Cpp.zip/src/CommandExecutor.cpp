#include "CommandExecutor.h"
#include "store/EmployeeStoreImpl.h"

CommandExecutor::CommandExecutor()
    : employeeStore_(std::make_shared<EmployeeStoreImpl>()) {}

CommandExecutor::CommandExecutor(std::shared_ptr<EmployeeStore> store)
    : employeeStore_(store) {}

std::vector<std::string> CommandExecutor::execute(Command& command) {
    return command.execute(*employeeStore_);
}
