#include "CommandReader.h"
#include "CommandParser.h"
#include "CommandFactory.h"
#include "CommandExecutor.h"
#include "Printer.h"
#include <iostream>
#include <stdexcept>

void printUsage() {
    std::cout << "Input / output format is txt file. Read input file and generate output file." << std::endl;
    std::cout << "Usage : EmployeeManagement input.txt output.txt" << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printUsage();
        std::cerr << "Wrong arguments count" << std::endl;
        return 1;
    }

    std::string inputFileName = argv[1];
    std::string outputFilename = argv[2];

    CommandReader commandReader(inputFileName);
    CommandParser commandParser;
    CommandFactory commandFactory;
    CommandExecutor commandExecutor;
    Printer printer(outputFilename);

    auto input = commandReader.readFile();

    for (const auto& line : input) {
        try {
            TokenGroup tokenGroup = commandParser.parse(line);
            auto command = commandFactory.buildCommand(tokenGroup);
            auto result = commandExecutor.execute(*command);
            printer.add(result);
        } catch (const std::exception& e) {
            printer.add({"wrong command : " + line});
        }
    }

    printer.printOutputFile();
    return 0;
}
