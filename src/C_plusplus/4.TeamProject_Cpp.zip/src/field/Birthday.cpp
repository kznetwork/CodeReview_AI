#include "field/Birthday.h"
#include <stdexcept>
#include <cstdio>

Birthday::Birthday(const std::string& birthday) {
    if (birthday.size() != 8) {
        throw std::invalid_argument("Invalid birthday format: " + birthday);
    }
    year_ = std::stoi(birthday.substr(0, 4));
    month_ = std::stoi(birthday.substr(4, 2));
    day_ = std::stoi(birthday.substr(6, 2));
}

Birthday::Birthday(int year, int month, int day)
    : year_(year), month_(month), day_(day) {}

int Birthday::toInt() const {
    return year_ * 10000 + month_ * 100 + day_;
}

std::string Birthday::toString() const {
    char buf[9];
    std::snprintf(buf, sizeof(buf), "%04d%02d%02d", year_, month_, day_);
    return std::string(buf);
}

bool Birthday::equals(const std::string& str) const {
    return toString() == str;
}

bool Birthday::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const Birthday&>(field);
    int dataValue, searchValue;
    switch (subfieldIndex) {
        case 0:
            dataValue = toInt();
            searchValue = other.toInt();
            break;
        case 1:
            dataValue = year_;
            searchValue = other.year_;
            break;
        case 2:
            dataValue = month_;
            searchValue = other.month_;
            break;
        case 3:
            dataValue = day_;
            searchValue = other.day_;
            break;
        default:
            throw std::invalid_argument("Invalid subfieldIndex: " + std::to_string(subfieldIndex));
    }
    return compareInt(dataValue, searchValue, tertiaryOption);
}

int Birthday::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const Birthday&>(other);
    if (year_ != o.year_) return year_ - o.year_;
    if (month_ != o.month_) return month_ - o.month_;
    return day_ - o.day_;
}
