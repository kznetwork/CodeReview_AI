#include "field/PhoneNumber.h"
#include <stdexcept>
#include <sstream>

PhoneNumber::PhoneNumber(const std::string& phoneNumber) : phoneNumber_(phoneNumber) {
    if (phoneNumber.size() != 13) {
        throw std::invalid_argument("Invalid PhoneNumber format: " + phoneNumber);
    }
    // Split by '-'
    std::istringstream ss(phoneNumber);
    std::string token;
    std::vector<std::string> parts;
    while (std::getline(ss, token, '-')) {
        parts.push_back(token);
    }
    if (parts.size() != 3) {
        throw std::invalid_argument("Invalid PhoneNumber split: " + phoneNumber);
    }
    first_ = parts[0];
    middle_ = parts[1];
    last_ = parts[2];
}

std::string PhoneNumber::toString() const {
    return first_ + "-" + middle_ + "-" + last_;
}

bool PhoneNumber::equals(const std::string& str) const {
    PhoneNumber other(str);
    return first_ == other.first_ && middle_ == other.middle_ && last_ == other.last_;
}

bool PhoneNumber::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const PhoneNumber&>(field);
    if (subfieldIndex == 2) {
        return compareString(middle_, other.middle_, tertiaryOption);
    } else if (subfieldIndex == 3) {
        return compareString(last_, other.last_, tertiaryOption);
    }
    return compareString(phoneNumber_, other.phoneNumber_, tertiaryOption);
}

int PhoneNumber::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const PhoneNumber&>(other);
    return phoneNumber_.compare(o.phoneNumber_);
}
