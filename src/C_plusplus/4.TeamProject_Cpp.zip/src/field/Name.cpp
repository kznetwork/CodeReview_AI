#include "field/Name.h"
#include <stdexcept>

Name::Name(const std::string& first, const std::string& second)
    : first_(first), second_(second) {}

Name::Name(const std::string& fullName) {
    auto pos = fullName.find(' ');
    if (pos == std::string::npos) {
        throw std::invalid_argument("Invalid name format: " + fullName);
    }
    first_ = fullName.substr(0, pos);
    second_ = fullName.substr(pos + 1);
}

std::string Name::toString() const {
    return first_ + " " + second_;
}

bool Name::equals(const std::string& str) const {
    Name other(str);
    return first_ == other.first_ && second_ == other.second_;
}

bool Name::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const Name&>(field);
    switch (subfieldIndex) {
        case 0:
            if (first_ == other.first_) {
                return compareString(second_, other.second_, tertiaryOption);
            }
            return compareString(first_, other.first_, tertiaryOption);
        case 1:
            return compareString(first_, other.first_, tertiaryOption);
        case 2:
            return compareString(second_, other.second_, tertiaryOption);
        default:
            throw std::invalid_argument("Subfield index out of bounds: " + std::to_string(subfieldIndex));
    }
}

int Name::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const Name&>(other);
    if (first_ == o.first_) {
        return second_.compare(o.second_);
    }
    return first_.compare(o.first_);
}
