#include "field/EmployeeNumber.h"
#include <stdexcept>

EmployeeNumber::EmployeeNumber(const std::string& number)
    : number_(number) {
    year_ = number.substr(0, 2);
    mod_ = number.substr(2, 6);
}

int EmployeeNumber::getYear() const {
    return std::stoi(year_);
}

int EmployeeNumber::getMod() const {
    return std::stoi(mod_);
}

std::string EmployeeNumber::toString() const {
    return number_;
}

bool EmployeeNumber::equals(const std::string& str) const {
    return number_ == str;
}

bool EmployeeNumber::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const EmployeeNumber&>(field);
    int standardYear = other.getYear();
    int standardMod = other.getMod();
    int y = getYear();
    int m = getMod();

    if (standardYear <= 19) standardYear += 100;
    if (y <= 19) y += 100;

    if (y == standardYear) {
        return compareInt(m, standardMod, tertiaryOption);
    }
    return compareInt(y, standardYear, tertiaryOption);
}

int EmployeeNumber::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const EmployeeNumber&>(other);
    return number_.compare(o.number_);
}
