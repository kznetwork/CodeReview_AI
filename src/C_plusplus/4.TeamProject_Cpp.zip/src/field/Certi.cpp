#include "field/Certi.h"
#include <stdexcept>

Certi::Certi(const std::string& certi) : certi_(certi) {}

int Certi::getCertiLevel() const {
    if (certi_ == "ADV") return 0;
    if (certi_ == "PRO") return 1;
    if (certi_ == "EX") return 2;
    throw std::invalid_argument("Invalid certi: " + certi_);
}

std::string Certi::toString() const {
    return certi_;
}

bool Certi::equals(const std::string& str) const {
    return certi_ == str;
}

bool Certi::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const Certi&>(field);
    return compareInt(getCertiLevel(), other.getCertiLevel(), tertiaryOption);
}

int Certi::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const Certi&>(other);
    int a = getCertiLevel();
    int b = o.getCertiLevel();
    if (a == b) return 0;
    return a > b ? 1 : -1;
}
