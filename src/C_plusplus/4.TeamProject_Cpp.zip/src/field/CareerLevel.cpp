#include "field/CareerLevel.h"
#include <stdexcept>
#include <regex>

CareerLevel::CareerLevel(const std::string& value) : value_(value) {
    if (value.size() != 3 || value.substr(0, 2) != "CL" ||
        value[2] < '1' || value[2] > '4') {
        throw std::invalid_argument("Invalid career level: " + value);
    }
    levelNum_ = value[2] - '0';
}

std::string CareerLevel::toString() const {
    return value_;
}

bool CareerLevel::equals(const std::string& str) const {
    return value_ == str;
}

bool CareerLevel::compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const {
    const auto& other = dynamic_cast<const CareerLevel&>(field);
    if (subfieldIndex != 0) {
        throw std::invalid_argument("CareerLevel only supports subfieldIndex == 0");
    }
    return compareInt(levelNum_, other.levelNum_, tertiaryOption);
}

int CareerLevel::compareTo(const Field& other) const {
    const auto& o = dynamic_cast<const CareerLevel&>(other);
    return levelNum_ - o.levelNum_;
}
