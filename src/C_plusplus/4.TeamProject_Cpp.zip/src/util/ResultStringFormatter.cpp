#include "util/ResultStringFormatter.h"
#include <algorithm>
#include <sstream>

int ResultStringFormatter::getEmployeeNumber(int employeeNumber) {
    return employeeNumber >= YEAR_1990_EMPLOYEE_NUMBER
        ? YEAR_PREFIX_19 + employeeNumber
        : YEAR_PREFIX_20 + employeeNumber;
}

std::string ResultStringFormatter::getEmployeeToFormattedString(const std::string& commandType, const Employee& employee) {
    return commandType + "," + employee.getEmployeeNumber().toString() + "," +
           employee.getName().toString() + "," +
           employee.getCareerLevel().toString() + "," +
           employee.getPhoneNumber().toString() + "," +
           employee.getBirthday().toString() + "," +
           employee.getCerti().toString();
}

std::vector<std::string> ResultStringFormatter::getEmployeeListToFormattedString(
    const std::vector<Employee>& employeeList, const std::string& commandType, int count) {

    if (employeeList.empty()) {
        return { commandType + ",NONE" };
    }

    // Sort by employee number (year ascending)
    std::vector<Employee> sorted = employeeList;
    std::sort(sorted.begin(), sorted.end(), [](const Employee& a, const Employee& b) {
        int numA = std::stoi(a.getEmployeeNumber().toString());
        int numB = std::stoi(b.getEmployeeNumber().toString());
        return getEmployeeNumber(numA) < getEmployeeNumber(numB);
    });

    std::vector<std::string> result;
    int limit = std::min(count, static_cast<int>(sorted.size()));
    for (int i = 0; i < limit; ++i) {
        result.push_back(getEmployeeToFormattedString(commandType, sorted[i]));
    }
    return result;
}

std::vector<std::string> ResultStringFormatter::getEmployeeListToFormattedString(
    const std::vector<Employee>& employeeList, const std::string& commandType) {

    std::string formatted = employeeList.empty() ? "NONE" : std::to_string(employeeList.size());
    return { commandType + "," + formatted };
}
