#include "util/OptionParser.h"
#include "store/FieldEnum.h"
#include "field/Field.h"
#include <stdexcept>

// --- TertiaryOptionEnum helpers (defined in Field.h) ---
TertiaryOptionEnum tertiaryOptionFromString(const std::string& option) {
    if (option == "-g") return TertiaryOptionEnum::G;
    if (option == "-ge") return TertiaryOptionEnum::GE;
    if (option == "-s") return TertiaryOptionEnum::S;
    if (option == "-se") return TertiaryOptionEnum::SE;
    if (option == " " || option.empty()) return TertiaryOptionEnum::NONE;
    throw std::invalid_argument("Invalid tertiary option: " + option);
}

std::string tertiaryOptionToString(TertiaryOptionEnum opt) {
    switch (opt) {
        case TertiaryOptionEnum::G: return "-g";
        case TertiaryOptionEnum::GE: return "-ge";
        case TertiaryOptionEnum::S: return "-s";
        case TertiaryOptionEnum::SE: return "-se";
        default: return " ";
    }
}

// --- Field base class helpers ---
bool Field::compareString(const std::string& first, const std::string& second, TertiaryOptionEnum opt) const {
    int cmp = first.compare(second);
    switch (opt) {
        case TertiaryOptionEnum::G: return cmp > 0;
        case TertiaryOptionEnum::GE: return cmp >= 0;
        case TertiaryOptionEnum::NONE: return cmp == 0;
        case TertiaryOptionEnum::SE: return cmp <= 0;
        case TertiaryOptionEnum::S: return cmp < 0;
    }
    return false;
}

bool Field::compareInt(int first, int second, TertiaryOptionEnum opt) const {
    switch (opt) {
        case TertiaryOptionEnum::G: return first > second;
        case TertiaryOptionEnum::GE: return first >= second;
        case TertiaryOptionEnum::NONE: return first == second;
        case TertiaryOptionEnum::SE: return first <= second;
        case TertiaryOptionEnum::S: return first < second;
    }
    return false;
}

// --- PrimaryOptionEnum ---
PrimaryOptionEnum primaryOptionFromString(const std::string& option) {
    if (option == "-p") return PrimaryOptionEnum::PRINT;
    if (option == " " || option.empty()) return PrimaryOptionEnum::NONE;
    throw std::invalid_argument("Invalid primary option: " + option);
}

// --- SecondaryOptionEnum ---
SecondaryOptionEnum secondaryOptionFromString(const std::string& option) {
    if (option == "-f") return SecondaryOptionEnum::F;
    if (option == "-l") return SecondaryOptionEnum::L;
    if (option == "-m") return SecondaryOptionEnum::M;
    if (option == "-y") return SecondaryOptionEnum::Y;
    if (option == "-d") return SecondaryOptionEnum::D;
    if (option == " " || option.empty()) return SecondaryOptionEnum::NONE;
    throw std::invalid_argument("Invalid secondary option: " + option);
}

int getSecondaryOptionType(SecondaryOptionEnum opt) {
    return static_cast<int>(opt);
}

// --- OptionParser ---
OptionParser::OptionParser(const std::vector<std::string>& options) {
    if (options.empty()) return;

    if (options.size() == 3) {
        if (!options[0].empty()) primaryOption_ = primaryOptionFromString(options[0]);
        if (!options[1].empty()) secondaryOption_ = secondaryOptionFromString(options[1]);
        if (!options[2].empty()) tertiaryOption_ = tertiaryOptionFromString(options[2]);
    } else if (options.size() == 2) {
        if (!options[0].empty()) secondaryOption_ = secondaryOptionFromString(options[0]);
        if (!options[1].empty()) tertiaryOption_ = tertiaryOptionFromString(options[1]);
    }
}

int getFieldIndexFromOption(const OptionParser& optionParser, FieldEnum inputFieldEnum) {
    SecondaryOptionEnum secondaryOption = optionParser.getSecondaryOption();
    int fieldIndex = 0;
    switch (secondaryOption) {
        case SecondaryOptionEnum::F:
            fieldIndex = 1;
            break;
        case SecondaryOptionEnum::M:
            if (inputFieldEnum == FieldEnum::FIELD_PHONE_NUMBER) {
                fieldIndex = 2;
            } else if (inputFieldEnum == FieldEnum::FIELD_BIRTH_DAY) {
                fieldIndex = 2;
            }
            break;
        case SecondaryOptionEnum::L:
            if (inputFieldEnum == FieldEnum::FIELD_PHONE_NUMBER) {
                fieldIndex = 3;
            } else if (inputFieldEnum == FieldEnum::FIELD_NAME) {
                fieldIndex = 2;
            }
            break;
        case SecondaryOptionEnum::Y:
            if (inputFieldEnum == FieldEnum::FIELD_BIRTH_DAY) {
                fieldIndex = 1;
            }
            break;
        case SecondaryOptionEnum::D:
            if (inputFieldEnum == FieldEnum::FIELD_BIRTH_DAY) {
                fieldIndex = 3;
            }
            break;
        case SecondaryOptionEnum::NONE:
            break;
    }
    return fieldIndex;
}
