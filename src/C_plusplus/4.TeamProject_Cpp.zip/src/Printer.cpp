#include "Printer.h"
#include <fstream>
#include <iostream>

Printer::Printer(const std::string& outputFilename)
    : outputFileName_(outputFilename) {}

void Printer::add(const std::vector<std::string>& lines) {
    for (const auto& line : lines) {
        buffer_ += line + "\n";
    }
}

void Printer::printOutputFile() const {
    std::ofstream file(outputFileName_);
    if (!file.is_open()) {
        std::cerr << "Failed to open output file: " << outputFileName_ << std::endl;
        return;
    }
    file << buffer_;
}
