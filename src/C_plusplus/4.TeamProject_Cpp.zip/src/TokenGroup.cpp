#include "TokenGroup.h"

TokenGroup::TokenGroup(const std::string& type,
                       const std::vector<std::string>& options,
                       const std::vector<std::string>& params)
    : type_(type), firstOptions_(options), firstParams_(params), combination_(" ") {}

TokenGroup::TokenGroup(const std::string& type,
                       const std::vector<std::string>& firstOptions,
                       const std::vector<std::string>& firstParams,
                       const std::string& combination,
                       const std::vector<std::string>& secondOptions,
                       const std::vector<std::string>& secondParams)
    : type_(type), firstOptions_(firstOptions), firstParams_(firstParams)
    , combination_(combination), secondOptions_(secondOptions), secondParams_(secondParams) {}
