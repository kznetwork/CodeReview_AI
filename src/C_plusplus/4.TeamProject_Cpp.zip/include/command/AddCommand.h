#pragma once
#include "command/Command.h"
#include "store/Employee.h"

class AddCommand : public Command {
public:
    AddCommand(std::shared_ptr<OptionParser> optionParser, const Employee& employee);
    std::vector<std::string> execute(EmployeeStore& employeeStore) override;

private:
    Employee employee_;
    std::shared_ptr<OptionParser> optionParser_;
};
