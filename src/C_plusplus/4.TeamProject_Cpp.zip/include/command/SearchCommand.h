#pragma once
#include "command/Command.h"

class SearchCommand : public Command {
public:
    // Single
    SearchCommand(std::shared_ptr<OptionParser> optionParser,
                  Pair<std::string, std::string> conditionPair);
    // AndOr
    SearchCommand(std::shared_ptr<OptionParser> firstOptionParser,
                  Pair<std::string, std::string> firstConditionPair,
                  CombinationEnum combinationEnum,
                  std::shared_ptr<OptionParser> secondOptionParser,
                  Pair<std::string, std::string> secondConditionPair);

protected:
    std::vector<std::string> executeSingle(EmployeeStore& employeeStore) override;
    std::vector<std::string> executeAndOr(EmployeeStore& employeeStore) override;
};
