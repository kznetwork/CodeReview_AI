#pragma once
#include "command/Command.h"

class CountCommand : public Command {
public:
    std::vector<std::string> execute(EmployeeStore& employeeStore) override;
};
