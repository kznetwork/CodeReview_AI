#pragma once
#include "command/Command.h"

class ModCommand : public Command {
public:
    // Single
    ModCommand(std::shared_ptr<OptionParser> optionParser,
               Pair<std::string, std::string> conditionPair,
               Pair<std::string, std::string> conditionModifyPair);
    // AndOr
    ModCommand(std::shared_ptr<OptionParser> firstOptionParser,
               Pair<std::string, std::string> firstConditionPair,
               CombinationEnum combinationEnum,
               std::shared_ptr<OptionParser> secondOptionParser,
               Pair<std::string, std::string> secondConditionPair,
               Pair<std::string, std::string> conditionModifyPair);

protected:
    std::vector<std::string> executeSingle(EmployeeStore& employeeStore) override;
    std::vector<std::string> executeAndOr(EmployeeStore& employeeStore) override;

private:
    Pair<std::string, std::string> conditionModifyPair_;
};
