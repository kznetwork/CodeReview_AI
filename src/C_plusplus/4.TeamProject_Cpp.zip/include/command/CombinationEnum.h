#pragma once
#include <string>

enum class CombinationEnum {
    NONE,
    OR,
    AND
};

inline CombinationEnum combinationFromString(const std::string& str) {
    if (str == "-a") return CombinationEnum::AND;
    if (str == "-o") return CombinationEnum::OR;
    return CombinationEnum::NONE;
}

inline std::string combinationToString(CombinationEnum c) {
    switch (c) {
        case CombinationEnum::AND: return "-a";
        case CombinationEnum::OR: return "-o";
        default: return " ";
    }
}
