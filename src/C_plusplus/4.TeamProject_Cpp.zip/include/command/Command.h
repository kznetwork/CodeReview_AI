#pragma once
#include "store/EmployeeStore.h"
#include "util/OptionParser.h"
#include "util/Pair.h"
#include "command/CombinationEnum.h"
#include <vector>
#include <string>
#include <memory>

class Command {
public:
    virtual ~Command() = default;

    Command() = default;

    // Single
    Command(std::shared_ptr<OptionParser> firstOptionParser,
            Pair<std::string, std::string> firstConditionPair);

    // AndOr
    Command(std::shared_ptr<OptionParser> firstOptionParser,
            Pair<std::string, std::string> firstConditionPair,
            CombinationEnum combinationEnum,
            std::shared_ptr<OptionParser> secondOptionParser,
            Pair<std::string, std::string> secondConditionPair);

    virtual std::vector<std::string> execute(EmployeeStore& employeeStore);

protected:
    virtual std::vector<std::string> executeSingle(EmployeeStore& employeeStore);
    virtual std::vector<std::string> executeAndOr(EmployeeStore& employeeStore);

    std::shared_ptr<OptionParser> firstOptionParser_;
    Pair<std::string, std::string> firstConditionPair_;
    CombinationEnum combinationEnum_ = CombinationEnum::NONE;
    std::shared_ptr<OptionParser> secondOptionParser_;
    Pair<std::string, std::string> secondConditionPair_;
};
