#pragma once
#include <string>
#include <vector>

class Printer {
public:
    explicit Printer(const std::string& outputFilename);

    void add(const std::vector<std::string>& lines);
    void printOutputFile() const;

private:
    std::string outputFileName_;
    std::string buffer_;
};
