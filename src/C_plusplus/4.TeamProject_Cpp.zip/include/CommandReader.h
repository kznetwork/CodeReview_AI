#pragma once
#include <string>
#include <vector>

class CommandReader {
public:
    explicit CommandReader(const std::string& inputFileName);
    std::vector<std::string> readFile() const;

private:
    std::string inputFileName_;
};
