#pragma once
#include "TokenGroup.h"
#include <string>

class CommandParser {
public:
    TokenGroup parse(const std::string& line) const;

private:
    static int getConditionIndex(const std::vector<std::string>& params);
    static std::vector<std::string> getValidList(const std::vector<std::string>& list);
};
