#pragma once
#include "command/CombinationEnum.h"
#include <vector>
#include <string>

class TokenGroup {
public:
    // Single
    TokenGroup(const std::string& type,
               const std::vector<std::string>& options,
               const std::vector<std::string>& params);

    // AndOr
    TokenGroup(const std::string& type,
               const std::vector<std::string>& firstOptions,
               const std::vector<std::string>& firstParams,
               const std::string& combination,
               const std::vector<std::string>& secondOptions,
               const std::vector<std::string>& secondParams);

    const std::string& getType() const { return type_; }
    const std::vector<std::string>& getOptions() const { return firstOptions_; }
    const std::vector<std::string>& getParams() const { return firstParams_; }
    CombinationEnum getCombinationEnum() const { return combinationFromString(combination_); }

    const std::vector<std::string>& getFirstOptions() const { return firstOptions_; }
    const std::vector<std::string>& getFirstParams() const { return firstParams_; }
    const std::string& getCombination() const { return combination_; }
    const std::vector<std::string>& getSecondOptions() const { return secondOptions_; }
    const std::vector<std::string>& getSecondParams() const { return secondParams_; }

private:
    std::string type_;
    std::vector<std::string> firstOptions_;
    std::vector<std::string> firstParams_;
    std::string combination_;
    std::vector<std::string> secondOptions_;
    std::vector<std::string> secondParams_;
};
