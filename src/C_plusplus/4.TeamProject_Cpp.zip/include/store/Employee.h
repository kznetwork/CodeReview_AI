#pragma once
#include "field/EmployeeNumber.h"
#include "field/Name.h"
#include "field/CareerLevel.h"
#include "field/PhoneNumber.h"
#include "field/Birthday.h"
#include "field/Certi.h"
#include <memory>
#include <string>

class Employee {
public:
    Employee(const std::string& employeeNumber,
             const std::string& name,
             const std::string& careerLevel,
             const std::string& phoneNumber,
             const std::string& birthday,
             const std::string& certi);

    Employee(const Employee& other);
    Employee& operator=(const Employee& other);

    const EmployeeNumber& getEmployeeNumber() const { return employeeNumber_; }
    const Name& getName() const { return name_; }
    const CareerLevel& getCareerLevel() const { return careerLevel_; }
    const PhoneNumber& getPhoneNumber() const { return phoneNumber_; }
    const Birthday& getBirthday() const { return birthday_; }
    const Certi& getCerti() const { return certi_; }

    void setName(const Name& name) { name_ = name; }
    void setCareerLevel(const CareerLevel& cl) { careerLevel_ = cl; }
    void setPhoneNumber(const PhoneNumber& phone) { phoneNumber_ = phone; }
    void setBirthday(const Birthday& birthday) { birthday_ = birthday; }
    void setCerti(const Certi& certi) { certi_ = certi; }
    void setEmployeeNumber(const EmployeeNumber& num) { employeeNumber_ = num; }

    bool operator==(const Employee& other) const;

private:
    EmployeeNumber employeeNumber_;
    Name name_;
    CareerLevel careerLevel_;
    PhoneNumber phoneNumber_;
    Birthday birthday_;
    Certi certi_;
};
