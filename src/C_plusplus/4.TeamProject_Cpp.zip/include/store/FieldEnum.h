#pragma once
#include <string>
#include <stdexcept>

enum class FieldEnum {
    FIELD_EMPLOYEE_NUMBER,
    FIELD_NAME,
    FIELD_FIRST_NAME,
    FIELD_SECOND_NAME,
    FIELD_CAREER_LEVEL,
    FIELD_PHONE_NUMBER,
    FIELD_PHONE_NUMBER_MIDDLE,
    FIELD_PHONE_NUMBER_LAST,
    FIELD_BIRTH_DAY,
    FIELD_BIRTH_DAY_YEAR,
    FIELD_BIRTH_DAY_MONTH,
    FIELD_BIRTH_DAY_DAY,
    FIELD_CERTI
};

inline std::string fieldEnumToString(FieldEnum f) {
    switch (f) {
        case FieldEnum::FIELD_EMPLOYEE_NUMBER: return "employeeNumber";
        case FieldEnum::FIELD_NAME: return "name";
        case FieldEnum::FIELD_FIRST_NAME: return "nameFirst";
        case FieldEnum::FIELD_SECOND_NAME: return "nameSecond";
        case FieldEnum::FIELD_CAREER_LEVEL: return "careerLevel";
        case FieldEnum::FIELD_PHONE_NUMBER: return "phoneNumber";
        case FieldEnum::FIELD_PHONE_NUMBER_MIDDLE: return "phoneNumberMiddle";
        case FieldEnum::FIELD_PHONE_NUMBER_LAST: return "phoneNumberLast";
        case FieldEnum::FIELD_BIRTH_DAY: return "birthDay";
        case FieldEnum::FIELD_BIRTH_DAY_YEAR: return "birthDayYear";
        case FieldEnum::FIELD_BIRTH_DAY_MONTH: return "birthDayMonth";
        case FieldEnum::FIELD_BIRTH_DAY_DAY: return "birthDayDay";
        case FieldEnum::FIELD_CERTI: return "certi";
        default: throw std::invalid_argument("Unknown FieldEnum");
    }
}

inline FieldEnum fieldEnumFromString(const std::string& field) {
    if (field == "employeeNumber") return FieldEnum::FIELD_EMPLOYEE_NUMBER;
    if (field == "name") return FieldEnum::FIELD_NAME;
    if (field == "nameFirst") return FieldEnum::FIELD_FIRST_NAME;
    if (field == "nameSecond") return FieldEnum::FIELD_SECOND_NAME;
    if (field == "careerLevel") return FieldEnum::FIELD_CAREER_LEVEL;
    if (field == "phoneNumber") return FieldEnum::FIELD_PHONE_NUMBER;
    if (field == "phoneNumberMiddle") return FieldEnum::FIELD_PHONE_NUMBER_MIDDLE;
    if (field == "phoneNumberLast") return FieldEnum::FIELD_PHONE_NUMBER_LAST;
    if (field == "birthDay") return FieldEnum::FIELD_BIRTH_DAY;
    if (field == "birthDayYear") return FieldEnum::FIELD_BIRTH_DAY_YEAR;
    if (field == "birthDayMonth") return FieldEnum::FIELD_BIRTH_DAY_MONTH;
    if (field == "birthDayDay") return FieldEnum::FIELD_BIRTH_DAY_DAY;
    if (field == "certi") return FieldEnum::FIELD_CERTI;
    throw std::invalid_argument("Invalid field name: " + field);
}
