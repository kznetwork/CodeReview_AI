#pragma once
#include "store/EmployeeStore.h"
#include <vector>
#include <functional>
#include <map>
#include <memory>

class EmployeeStoreImpl : public EmployeeStore {
public:
    EmployeeStoreImpl();

    void add(const Employee& employee) override;
    int count() const override;

    std::vector<Employee> search(FieldEnum field, const std::string& value,
                                  TertiaryOptionEnum tertiaryOption) override;
    std::vector<Employee> search(FieldEnum field, const std::string& value,
                                  TertiaryOptionEnum tertiaryOption, int subfieldIndex) override;
    std::vector<Employee> search(FieldEnum field1, const std::string& value1,
                                  TertiaryOptionEnum tertiary1, int subfieldIndex1,
                                  CombinationEnum combination,
                                  FieldEnum field2, const std::string& value2,
                                  TertiaryOptionEnum tertiary2, int subfieldIndex2) override;

    std::vector<Employee> del(FieldEnum field, const std::string& value) override;
    std::vector<Employee> del(FieldEnum field, const std::string& value, int subfieldIndex) override;
    std::vector<Employee> del(FieldEnum field, const std::string& value, int subfieldIndex,
                               CombinationEnum combination,
                               FieldEnum field2, const std::string& value2, int subfieldIndex2) override;

    std::vector<Employee> modify(FieldEnum field, const std::string& value,
                                  FieldEnum modifyField, const std::string& modifyValue) override;
    std::vector<Employee> modify(FieldEnum field, const std::string& value,
                                  FieldEnum modifyField, const std::string& modifyValue,
                                  int subfieldIndex) override;
    std::vector<Employee> modify(FieldEnum field, const std::string& value, int subfieldIndex,
                                  CombinationEnum combination,
                                  FieldEnum field2, const std::string& value2, int subfieldIndex2,
                                  FieldEnum modifyField, const std::string& modifyValue) override;

private:
    std::vector<Employee> employees_;

    using FieldCreator = std::function<std::unique_ptr<Field>(const std::string&)>;
    using FieldExtractor = std::function<const Field&(const Employee&)>;

    std::map<FieldEnum, FieldCreator> fieldCreators_;
    std::map<FieldEnum, FieldExtractor> fieldExtractors_;

    void initializeFieldMaps();
    static std::vector<Employee> modifyFieldOfList(FieldEnum modifyField, const std::string& modifyValue,
                                                    const std::vector<Employee>& employees);
};
