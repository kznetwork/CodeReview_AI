#pragma once
#include "store/Employee.h"
#include "store/FieldEnum.h"
#include "command/CombinationEnum.h"
#include <vector>
#include <string>

class EmployeeStore {
public:
    virtual ~EmployeeStore() = default;

    static constexpr const char* FIELD_EMPLOYEE_NUMBER = "employeeNumber";
    static constexpr const char* FIELD_NAME = "name";
    static constexpr const char* FIELD_FIRST_NAME = "firstName";
    static constexpr const char* FIELD_SECOND_NAME = "secondName";
    static constexpr const char* FIELD_CAREER_LEVEL = "careerLevel";
    static constexpr const char* FIELD_PHONE_NUMBER = "phoneNumber";
    static constexpr const char* FIELD_BIRTH_DAY = "birthDay";
    static constexpr const char* FIELD_CERTI = "certi";

    virtual void add(const Employee& employee) = 0;
    virtual int count() const = 0;

    virtual std::vector<Employee> search(FieldEnum field, const std::string& value,
                                          TertiaryOptionEnum tertiaryOption) = 0;
    virtual std::vector<Employee> search(FieldEnum field, const std::string& value,
                                          TertiaryOptionEnum tertiaryOption, int subfieldIndex) = 0;
    virtual std::vector<Employee> search(FieldEnum field1, const std::string& value1,
                                          TertiaryOptionEnum tertiary1, int subfieldIndex1,
                                          CombinationEnum combination,
                                          FieldEnum field2, const std::string& value2,
                                          TertiaryOptionEnum tertiary2, int subfieldIndex2) = 0;

    virtual std::vector<Employee> del(FieldEnum field, const std::string& value) = 0;
    virtual std::vector<Employee> del(FieldEnum field, const std::string& value, int subfieldIndex) = 0;
    virtual std::vector<Employee> del(FieldEnum field, const std::string& value, int subfieldIndex,
                                       CombinationEnum combination,
                                       FieldEnum field2, const std::string& value2, int subfieldIndex2) = 0;

    virtual std::vector<Employee> modify(FieldEnum field, const std::string& value,
                                          FieldEnum modifyField, const std::string& modifyValue) = 0;
    virtual std::vector<Employee> modify(FieldEnum field, const std::string& value,
                                          FieldEnum modifyField, const std::string& modifyValue,
                                          int subfieldIndex) = 0;
    virtual std::vector<Employee> modify(FieldEnum field, const std::string& value, int subfieldIndex,
                                          CombinationEnum combination,
                                          FieldEnum field2, const std::string& value2, int subfieldIndex2,
                                          FieldEnum modifyField, const std::string& modifyValue) = 0;
};
