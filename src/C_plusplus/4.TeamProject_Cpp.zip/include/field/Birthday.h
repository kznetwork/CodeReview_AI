#pragma once
#include "field/Field.h"
#include <string>

class Birthday : public Field {
public:
    explicit Birthday(const std::string& birthday);
    Birthday(int year, int month, int day);

    int getYear() const { return year_; }
    int getMonth() const { return month_; }
    int getDay() const { return day_; }

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    int year_;
    int month_;
    int day_;
    int toInt() const;
};
