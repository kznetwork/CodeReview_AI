#pragma once
#include "field/Field.h"
#include <string>

class Certi : public Field {
public:
    explicit Certi(const std::string& certi);

    int getCertiLevel() const;

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    std::string certi_;
};
