#pragma once
#include "field/Field.h"
#include <string>

class PhoneNumber : public Field {
public:
    explicit PhoneNumber(const std::string& phoneNumber);

    const std::string& getFirst() const { return first_; }
    const std::string& getMiddle() const { return middle_; }
    const std::string& getLast() const { return last_; }

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    std::string phoneNumber_;
    std::string first_;
    std::string middle_;
    std::string last_;
};
