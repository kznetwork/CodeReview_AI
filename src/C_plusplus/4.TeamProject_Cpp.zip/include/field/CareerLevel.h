#pragma once
#include "field/Field.h"
#include <string>

class CareerLevel : public Field {
public:
    explicit CareerLevel(const std::string& value);

    const std::string& getValue() const { return value_; }
    int getLevelNum() const { return levelNum_; }

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    std::string value_;
    int levelNum_;
};
