#pragma once
#include "field/Field.h"
#include <string>

class Name : public Field {
public:
    Name(const std::string& first, const std::string& second);
    explicit Name(const std::string& fullName);

    const std::string& getFirst() const { return first_; }
    const std::string& getSecond() const { return second_; }

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    std::string first_;
    std::string second_;
};
