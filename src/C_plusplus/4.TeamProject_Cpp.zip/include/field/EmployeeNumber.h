#pragma once
#include "field/Field.h"
#include <string>

class EmployeeNumber : public Field {
public:
    explicit EmployeeNumber(const std::string& number);

    int getYear() const;
    int getMod() const;

    bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const override;
    bool equals(const std::string& str) const override;
    int compareTo(const Field& other) const override;
    std::string toString() const override;

private:
    std::string number_;
    std::string year_;
    std::string mod_;
};
