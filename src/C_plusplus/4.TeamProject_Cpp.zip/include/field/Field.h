#pragma once
#include <string>

enum class TertiaryOptionEnum {
    NONE = 0,
    G = 1,
    GE = 2,
    S = 3,
    SE = 4
};

TertiaryOptionEnum tertiaryOptionFromString(const std::string& option);
std::string tertiaryOptionToString(TertiaryOptionEnum opt);

class Field {
public:
    virtual ~Field() = default;
    virtual bool compare(const Field& field, int subfieldIndex, TertiaryOptionEnum tertiaryOption) const = 0;
    virtual bool equals(const std::string& str) const = 0;
    virtual int compareTo(const Field& other) const = 0;
    virtual std::string toString() const = 0;

protected:
    bool compareString(const std::string& first, const std::string& second, TertiaryOptionEnum opt) const;
    bool compareInt(int first, int second, TertiaryOptionEnum opt) const;
};
