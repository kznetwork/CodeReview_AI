#pragma once
#include "command/Command.h"
#include "TokenGroup.h"
#include <memory>
#include <string>
#include <map>

class CommandFactory {
public:
    static constexpr const char* CMD_ADD = "ADD";
    static constexpr const char* CMD_DEL = "DEL";
    static constexpr const char* CMD_SCH = "SCH";
    static constexpr const char* CMD_CNT = "CNT";
    static constexpr const char* CMD_MOD = "MOD";

    std::unique_ptr<Command> buildCommand(const TokenGroup& tokens) const;

    static std::unique_ptr<Command> buildSingleCommand(const std::string& cmd,
                                                        const std::vector<std::string>& options,
                                                        const std::vector<std::string>& params);

    static std::unique_ptr<Command> buildAndOrCommand(const TokenGroup& tokens);

    static std::string getFieldMapParam(const std::string& param);

private:
    static const std::map<std::string, std::string>& getFieldMap();

    static Pair<std::string, std::string> getConditionMapFromParams(
        const std::vector<std::string>& params, const OptionParser& optionParser);

    static Pair<std::string, std::string> getConditionMapFromModifyParams(
        const std::vector<std::string>& params, const OptionParser& optionParser);
};
