#pragma once
#include "command/Command.h"
#include "store/EmployeeStore.h"
#include <memory>
#include <vector>
#include <string>

class CommandExecutor {
public:
    static constexpr int MAX_RESULT_NUMBER = 5;

    CommandExecutor();
    explicit CommandExecutor(std::shared_ptr<EmployeeStore> store);

    std::vector<std::string> execute(Command& command);

private:
    std::shared_ptr<EmployeeStore> employeeStore_;
};
