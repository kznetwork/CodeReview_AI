#pragma once
#include "store/Employee.h"
#include <vector>
#include <string>

class ResultStringFormatter {
public:
    static std::vector<std::string> getEmployeeListToFormattedString(
        const std::vector<Employee>& employeeList, const std::string& commandType, int count);

    static std::vector<std::string> getEmployeeListToFormattedString(
        const std::vector<Employee>& employeeList, const std::string& commandType);

    static std::string getEmployeeToFormattedString(const std::string& commandType, const Employee& employee);

private:
    static constexpr int YEAR_1990_EMPLOYEE_NUMBER = 90000000;
    static constexpr int YEAR_PREFIX_19 = 1900000000;
    static constexpr int YEAR_PREFIX_20 = 2000000000;

    static int getEmployeeNumber(int employeeNumber);
};
