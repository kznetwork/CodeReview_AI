#pragma once
#include <string>

template <typename F, typename S>
struct Pair {
    F first;
    S second;

    Pair() = default;
    Pair(const F& f, const S& s) : first(f), second(s) {}

    bool operator==(const Pair& other) const {
        return first == other.first && second == other.second;
    }

    static Pair create(const F& f, const S& s) {
        return Pair(f, s);
    }
};
