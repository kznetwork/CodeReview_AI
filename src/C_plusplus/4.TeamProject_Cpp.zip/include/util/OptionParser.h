#pragma once
#include <string>
#include <vector>

enum class PrimaryOptionEnum {
    NONE = 0,
    PRINT = 1
};

PrimaryOptionEnum primaryOptionFromString(const std::string& option);

enum class SecondaryOptionEnum {
    NONE = 0,
    F = 1,
    L = 2,
    M = 3,
    Y = 4,
    D = 5
};

SecondaryOptionEnum secondaryOptionFromString(const std::string& option);
int getSecondaryOptionType(SecondaryOptionEnum opt);

class OptionParser {
public:
    explicit OptionParser(const std::vector<std::string>& options);

    PrimaryOptionEnum getPrimaryOption() const { return primaryOption_; }
    SecondaryOptionEnum getSecondaryOption() const { return secondaryOption_; }
    TertiaryOptionEnum getTertiaryOption() const { return tertiaryOption_; }

private:
    PrimaryOptionEnum primaryOption_ = PrimaryOptionEnum::NONE;
    SecondaryOptionEnum secondaryOption_ = SecondaryOptionEnum::NONE;
    TertiaryOptionEnum tertiaryOption_ = TertiaryOptionEnum::NONE;
};

// Utility: get subfield index from option and field
int getFieldIndexFromOption(const OptionParser& optionParser, FieldEnum inputFieldEnum);
