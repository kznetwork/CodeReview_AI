// person_test.cpp
#include "person.hpp"
#include <gtest/gtest.h>

class PersonTest : public ::testing::Test {
protected:
  Person *person;
  void SetUp() override { person = new Person("홍길동"); }
  void TearDown() override { delete person; }
};

TEST_F(PersonTest, GetName) { EXPECT_EQ("홍길동", person->getName()); }

TEST_F(PersonTest, SetName) {
  person->setName("이순신");
  EXPECT_EQ("이순신", person->getName());
}

TEST_F(PersonTest, NullNameThrows) {
  EXPECT_THROW(Person(nullptr), std::invalid_argument);
}
