#ifndef PERSON_HPP
#define PERSON_HPP

#include <stdexcept>
#include <string>

class Person {
private:
  std::string name;

public:
  Person(const std::string &name) : name(name) {}

  Person(std::nullptr_t) {
    throw std::invalid_argument("이름은 null일 수 없습니다.");
  }

  std::string getName() const { return name; }

  void setName(const std::string &name) { this->name = name; }
};

#endif // PERSON_HPP
