C:\DEV\PersonTDD_1004>rmdir /s /q build

C:\DEV\PersonTDD_1004>cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_C_COMPILER=C:/mingw64/bin/gcc.exe -DCMAKE_CXX_COMPILER=C:/mingw64/bin/g++.exe -DCMAKE_MAKE_PROGRAM=C:/mingw64/bin/mingw32-make.exe
-- The C compiler identification is GNU 15.2.0
-- The CXX compiler identification is GNU 15.2.0
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working C compiler: C:/mingw64/bin/gcc.exe - skipped
-- Detecting C compile features
-- Detecting C compile features - done
-- Detecting CXX compiler ABI info
-- Detecting CXX compiler ABI info - done
-- Check for working CXX compiler: C:/mingw64/bin/g++.exe - skipped
-- Detecting CXX compile features
-- Detecting CXX compile features - done
-- Configuring done (2.8s)
-- Generating done (0.1s)
-- Build files have been written to: C:/DEV/PersonTDD_1004/build

C:\DEV\PersonTDD_1004>cmake --build build
[ 10%] Building CXX object googletest-1.16.0/googletest/CMakeFiles/gtest.dir/src/gtest-all.cc.obj
[ 20%] Linking CXX static library ..\..\lib\libgtest.a
[ 20%] Built target gtest
[ 30%] Building CXX object googletest-1.16.0/googletest/CMakeFiles/gtest_main.dir/src/gtest_main.cc.obj
[ 40%] Linking CXX static library ..\..\lib\libgtest_main.a
[ 40%] Built target gtest_main
[ 50%] Building CXX object CMakeFiles/person_test.dir/test/person_test.cpp.obj
[ 60%] Linking CXX executable person_test.exe
[ 60%] Built target person_test
[ 70%] Building CXX object googletest-1.16.0/googlemock/CMakeFiles/gmock.dir/src/gmock-all.cc.obj
[ 80%] Linking CXX static library ..\..\lib\libgmock.a
[ 80%] Built target gmock
[ 90%] Building CXX object googletest-1.16.0/googlemock/CMakeFiles/gmock_main.dir/src/gmock_main.cc.obj
[100%] Linking CXX static library ..\..\lib\libgmock_main.a
[100%] Built target gmock_main

C:\DEV\PersonTDD_1004>cd build

C:\DEV\PersonTDD_1004\build>ctest --output-on-failure
Test project C:/DEV/PersonTDD_1004/build
    Start 1: PersonTest.GetName
1/3 Test #1: PersonTest.GetName ...............   Passed    0.04 sec
    Start 2: PersonTest.SetName
2/3 Test #2: PersonTest.SetName ...............   Passed    0.04 sec
    Start 3: PersonTest.NullNameThrows
3/3 Test #3: PersonTest.NullNameThrows ........   Passed    0.04 sec

100% tests passed, 0 tests failed out of 3

Total Test time (real) =   0.13 sec

C:\DEV\PersonTDD_1004\build>dir /s *.gcda
 C 드라이브의 볼륨에는 이름이 없습니다.
 볼륨 일련 번호: CA0D-4260

 C:\DEV\PersonTDD_1004\build\CMakeFiles\person_test.dir\test 디렉터리

2026-05-12  오후 06:17            10,996 person_test.cpp.gcda
               1개 파일              10,996 바이트

     전체 파일:
               1개 파일              10,996 바이트
               0개 디렉터리  133,727,502,336 바이트 남음

C:\DEV\PersonTDD_1004\build>lcov --capture --directory . --output-file lcov.info
Capturing coverage data from .
Found gcov version: 15.2.0
Using intermediate gcov format
Scanning . for .gcda files ...
Found 1 data files in .
Processing CMakeFiles\person_test.dir\test\person_test.cpp.gcda
Finished .info-file creation

C:\DEV\PersonTDD_1004\build>cd ..

C:\DEV\PersonTDD_1004>lcov --capture --directory build --base-directory . --output-file lcov.info
Capturing coverage data from build
Found gcov version: 15.2.0
Using intermediate gcov format
Scanning build for .gcda files ...
Found 1 data files in build
Processing CMakeFiles\person_test.dir\test\person_test.cpp.gcda
Finished .info-file creation

C:\DEV\PersonTDD_1004>type lcov.info | findstr SF:
SF:C:\mingw64\include\c++\15.2.0\bits\alloc_traits.h
SF:C:\mingw64\include\c++\15.2.0\bits\basic_string.tcc
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\gtest-assertion-result.h
SF:C:\mingw64\include\c++\15.2.0\bits\ptr_traits.h
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\internal\gtest-type-util.h
SF:C:\mingw64\include\c++\15.2.0\x86_64-w64-mingw32\bits\c++config.h
SF:C:\mingw64\include\c++\15.2.0\bits\stl_iterator_base_types.h
SF:C:\mingw64\include\c++\15.2.0\bits\stl_function.h
SF:C:\DEV\PersonTDD_1004\src\person.hpp
SF:C:\mingw64\include\c++\15.2.0\bits\allocator.h
SF:C:\mingw64\include\c++\15.2.0\bits\move.h
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\internal\gtest-port.h
SF:C:\mingw64\include\c++\15.2.0\bits\new_allocator.h
SF:C:\DEV\PersonTDD_1004\test\person_test.cpp
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\gtest-printers.h
SF:C:\mingw64\include\c++\15.2.0\ext\alloc_traits.h
SF:C:\mingw64\include\c++\15.2.0\bits\unique_ptr.h
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\gtest.h
SF:C:\mingw64\include\c++\15.2.0\bits\stl_iterator.h
SF:C:\mingw64\include\c++\15.2.0\bits\stl_algobase.h
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\internal\gtest-internal.h
SF:C:\mingw64\include\c++\15.2.0\bits\basic_string.h
SF:C:\mingw64\include\c++\15.2.0\typeinfo
SF:C:\mingw64\include\c++\15.2.0\bits\char_traits.h
SF:C:\DEV\PersonTDD_1004\googletest-1.16.0\googletest\include\gtest\gtest-message.h
SF:C:\mingw64\include\c++\15.2.0\tuple
SF:C:\mingw64\include\c++\15.2.0\bits\stl_iterator_base_funcs.h

C:\DEV\PersonTDD_1004>