#pragma once
#include <string>

class StringProcessor {
public:
    // 입력 문자열의 단어들을 정렬하여 반환
    static std::string process(const std::string& input);
};
