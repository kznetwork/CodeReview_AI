#include "StringProcessor.h"
#include <sstream>
#include <vector>
#include <algorithm>

std::string StringProcessor::process(const std::string& input) {
    std::istringstream iss(input);
    std::vector<std::string> words;
    std::string word;

    while (iss >> word) {
        words.push_back(word);
    }

    std::sort(words.begin(), words.end());

    std::string result;
    for (size_t i = 0; i < words.size(); ++i) {
        if (i > 0) result += " ";
        result += words[i];
    }
    return result;
}
