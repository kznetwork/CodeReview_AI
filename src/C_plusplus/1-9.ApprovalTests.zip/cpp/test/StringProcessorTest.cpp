// --- 기본 사용법 ---
#define APPROVALS_GOOGLETEST
#include "ApprovalTests.hpp"
#include "StringProcessor.h"

// StringProcessor 테스트
TEST(StringProcessorTest, SortWords) {
    std::string input =
        "banana apple Orange Grape";
    std::string result =
        StringProcessor::process(input);

    ApprovalTests::Approvals::verify(result);
    // → StringProcessorTest.SortWords
    //   .approved.txt 와 비교
}
