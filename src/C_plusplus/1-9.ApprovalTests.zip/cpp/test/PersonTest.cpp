#include <gtest/gtest.h>
#include "ApprovalTests.hpp"
#include <vector>
#include <string>

// --- 컬렉션 Approval ---
TEST(PersonTest, ApproveList) {
    std::vector<std::string> names =
        {"Alice", "Bob", "Charlie"};

    ApprovalTests::Approvals::verifyAll(
        "Names", names);
    // approved.txt:
    // Names[0] = Alice
    // Names[1] = Bob
    // Names[2] = Charlie
}
