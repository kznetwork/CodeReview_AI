#include <gtest/gtest.h>
#include "Largest.h"

TEST(LargestTest, TestSimple) {
    EXPECT_EQ(9, Largest::largest({7, 8, 9}));
}

TEST(LargestTest, TestOrder) {
    EXPECT_EQ(9, Largest::largest({7, 9, 8}));
    EXPECT_EQ(9, Largest::largest({9, 8, 7}));
    EXPECT_EQ(9, Largest::largest({9, 7, 9, 8}));
}

TEST(LargestTest, TestSingleValue) {
    EXPECT_EQ(1, Largest::largest({1}));
}

TEST(LargestTest, TestNegativeValues) {
    EXPECT_EQ(-7, Largest::largest({-9, -8, -7}));
}

TEST(LargestTest, TestEmptyList) {
    EXPECT_THROW(Largest::largest({}), std::runtime_error);
}
