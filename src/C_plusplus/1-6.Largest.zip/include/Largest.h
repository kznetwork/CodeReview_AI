#ifndef LARGEST_H
#define LARGEST_H

#include <vector>

class Largest {
public:
    static int largest(const std::vector<int>& list);
};

#endif
