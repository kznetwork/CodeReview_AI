#include <iostream>
#include <vector>
#include "Largest.h"

int main() {
    std::vector<int> numbers = {7, 8, 9};
    std::cout << "Largest value: "
              << Largest::largest(numbers)
              << std::endl;
    return 0;
}
