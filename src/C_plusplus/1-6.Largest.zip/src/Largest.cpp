#include "Largest.h"
#include <limits>
#include <stdexcept>

int Largest::largest(const std::vector<int>& list) {
    if (list.empty()) {
        throw std::runtime_error("Empty List");
    }

    int max = std::numeric_limits<int>::min();
    for (int value : list) {
        if (value > max) {
            max = value;
        }
    }
    return max;
}
