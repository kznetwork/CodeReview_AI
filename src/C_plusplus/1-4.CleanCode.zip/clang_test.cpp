#include <cstdio>

int main()
{
    int a = 1;
    if (a == 1)
    {
        printf("hi");
    }
}