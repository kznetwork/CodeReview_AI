#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockMessageService.h"

using namespace testing;

// — 다양한 Times 지정 ——————————————
TEST(TimesTest, AnyNumberOfTimes) {
    MockMessageService mock;
    EXPECT_CALL(mock, sendMessage(_, _))
        .Times(AnyNumber())           // 0회 이상
        .WillRepeatedly(Return("ok"));

    mock.sendMessage("a", "b");
    mock.sendMessage("c", "d");
}

TEST(TimesTest, AtLeastOnce) {
    MockMessageService mock;
    EXPECT_CALL(mock, sendMessage(_, _))
        .Times(AtLeast(1))            // 1회 이상
        .WillRepeatedly(Return("ok"));

    mock.sendMessage("a", "b");
}

TEST(TimesTest, BetweenTwoAndFive) {
    MockMessageService mock;
    EXPECT_CALL(mock, sendMessage(_, _))
        .Times(Between(2, 5))         // 2~5회
        .WillRepeatedly(Return("ok"));

    mock.sendMessage("a", "1");
    mock.sendMessage("b", "2");
    mock.sendMessage("c", "3");
}
