#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockMessageService.h"

using namespace testing;

// — Stub (ON_CALL) – 반환값 설정 ——————————
TEST(StubTest, StubExample) {
    MockMessageService stub;

    // ON_CALL = 호출 시 반환값 지정 (검증 없음)
    ON_CALL(stub, sendMessage(_, _))
        .WillByDefault(Return("stubbed"));

    EXPECT_EQ("stubbed",
        stub.sendMessage("to", "msg"));
}
