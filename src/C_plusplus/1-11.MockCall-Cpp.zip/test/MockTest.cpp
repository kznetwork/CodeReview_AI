#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockMessageService.h"

using namespace testing;

// — Mock (EXPECT_CALL) – 행위 검증 ——————————
TEST(MockTest, MockExample) {
    MockMessageService mock;

    // EXPECT_CALL = 호출 횟수·인수까지 검증
    EXPECT_CALL(mock, sendMessage("to", "hello"))
        .Times(1)
        .WillOnce(Return("mocked"));

    EXPECT_EQ("mocked",
        mock.sendMessage("to", "hello"));
    // 테스트 종료 시 EXPECT_CALL 자동 검증
}
