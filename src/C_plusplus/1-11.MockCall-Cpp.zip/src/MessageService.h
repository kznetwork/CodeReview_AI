#pragma once
#include <string>

// 메시지 서비스 인터페이스
class MessageService {
public:
    virtual ~MessageService() = default;
    virtual std::string sendMessage(
        const std::string& to,
        const std::string& msg) = 0;
};
