#pragma once
#include <gmock/gmock.h>
#include "MessageService.h"

// — Mock 클래스 정의 ——————————————
class MockMessageService : public MessageService {
public:
    // MOCK_METHOD(반환타입, 메서드명, (인수타입...), (한정자))
    MOCK_METHOD(std::string, sendMessage,
        (const std::string& to,
         const std::string& msg),
        (override));
};
