#pragma once
#include "MessageService.h"

// — SPY – 실제 객체 감싸기 ——————————————
// (Google Mock: NiceMock/StrictMock으로 제어)
class RealMessageService : public MessageService {
public:
    std::string sendMessage(
        const std::string& to,
        const std::string& msg) override {
        return "real: " + msg;
    }
};
