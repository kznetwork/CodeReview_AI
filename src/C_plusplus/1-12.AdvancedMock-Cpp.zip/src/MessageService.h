#pragma once
#include <string>

class MessageService {
public:
    virtual ~MessageService() = default;
    virtual std::string sendMessage(
        const std::string& to,
        const std::string& msg) = 0;
};
