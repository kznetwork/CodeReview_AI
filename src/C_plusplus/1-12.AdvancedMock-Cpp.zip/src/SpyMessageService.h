#pragma once
#include <gmock/gmock.h>
#include "RealMessageService.h"

// 실제 구현 상속 후 일부만 override
class SpyMessageService : public RealMessageService {
public:
    MOCK_METHOD(std::string, sendMessage,
        (const std::string&,
         const std::string&),
        (override));
};
