#pragma once
#include <gmock/gmock.h>
#include "MessageService.h"

class MockMessageService : public MessageService {
public:
    MOCK_METHOD(std::string, sendMessage,
        (const std::string& to,
         const std::string& msg),
        (override));
};
