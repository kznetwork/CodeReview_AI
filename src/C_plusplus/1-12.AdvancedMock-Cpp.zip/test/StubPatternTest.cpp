#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockMessageService.h"

using namespace testing;

// — STUB – 다양한 WillByDefault 패턴 ——————————
TEST(StubPatternTest, DefaultReturn) {
    MockMessageService mock;
    ON_CALL(mock, sendMessage(_, _))
        .WillByDefault(Return("default"));

    EXPECT_EQ("default", mock.sendMessage("anyone", "anything"));
}

TEST(StubPatternTest, PriorityMatching) {
    MockMessageService mock;
    // 기본 반환
    ON_CALL(mock, sendMessage(_, _))
        .WillByDefault(Return("default"));
    // "vip"일 때 우선 매칭
    ON_CALL(mock, sendMessage("vip", _))
        .WillByDefault(Return("priority"));

    EXPECT_EQ("priority", mock.sendMessage("vip", "hello"));
    EXPECT_EQ("default",  mock.sendMessage("normal", "hello"));
}

// 예외 던지기
TEST(StubPatternTest, ThrowException) {
    MockMessageService mock;
    ON_CALL(mock, sendMessage(_, _))
        .WillByDefault(Throw(
            std::runtime_error("network error")));

    EXPECT_THROW(mock.sendMessage("to", "msg"), std::runtime_error);
}
