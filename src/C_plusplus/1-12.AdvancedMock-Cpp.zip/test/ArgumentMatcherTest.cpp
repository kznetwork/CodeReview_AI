#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockMessageService.h"

using namespace testing;

// — Argument Matchers ——————————————
// _ = 임의값, Eq(v), Ne(v), Gt, Lt
// StartsWith, HasSubstr, MatchesRegex
// ElementsAre, Contains, SizeIs
TEST(ArgumentMatcherTest, StartsWithAndHasSubstr) {
    MockMessageService mock;

    EXPECT_CALL(mock, sendMessage(
        StartsWith("vip"), HasSubstr("urgent")))
        .WillOnce(Return("matched"));

    EXPECT_EQ("matched",
        mock.sendMessage("vip_user", "urgent: help!"));
}

TEST(ArgumentMatcherTest, VariousMatchers) {
    MockMessageService mock;

    // Eq 매처
    EXPECT_CALL(mock, sendMessage(Eq("admin"), _))
        .WillOnce(Return("admin_response"));

    EXPECT_EQ("admin_response",
        mock.sendMessage("admin", "hello"));
}
