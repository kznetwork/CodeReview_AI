#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "SpyMessageService.h"

using namespace testing;

TEST(SpyTest, PartialOverride) {
    SpyMessageService spy;

    // 특정 호출만 가로채기
    EXPECT_CALL(spy, sendMessage("to", "msg"))
        .WillOnce(Return("fake"));

    // 나머지는 실제 호출로 위임
    ON_CALL(spy, sendMessage(Ne("to"), _))
        .WillByDefault([&](auto& a, auto& b) {
            return RealMessageService::sendMessage(a, b);
        });

    EXPECT_EQ("fake",
        spy.sendMessage("to", "msg"));
}
