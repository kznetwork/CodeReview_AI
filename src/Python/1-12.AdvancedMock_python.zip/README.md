# Advanced Mock - Python

Python `unittest.mock`을 활용한 Mock/Stub/Spy 패턴 예제 프로젝트입니다.

## 프로젝트 구조

```
src/
  message_service.py        # 추상 인터페이스 (ABC)
  real_message_service.py   # 실제 구현체
test/
  test_argument_matcher.py  # Argument Matcher 테스트
  test_spy.py               # Spy 패턴 테스트
  test_stub_pattern.py      # Stub 패턴 테스트
```

## 가상환경 설정 및 실행

### 1. 가상환경 생성

```bash
python -m venv venv
```

### 2. 가상환경 활성화

**Windows (CMD)**
```cmd
venv\Scripts\activate.bat
```

**Windows (PowerShell)**
```powershell
venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source venv/bin/activate
```

### 3. 의존성 설치

```bash
pip install pytest
```

### 4. 테스트 실행

```bash
python -m pytest test/ -v
```

### 5. 가상환경 비활성화

```bash
deactivate
```
