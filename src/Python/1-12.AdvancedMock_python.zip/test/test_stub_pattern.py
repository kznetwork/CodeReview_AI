import unittest
from unittest.mock import MagicMock

from src.message_service import MessageService


class TestStubPattern(unittest.TestCase):
    """STUB – 다양한 반환값 패턴"""

    def test_default_return(self):
        """기본 반환값 설정"""
        mock = MagicMock(spec=MessageService)
        mock.send_message.return_value = "default"

        self.assertEqual("default", mock.send_message("anyone", "anything"))

    def test_priority_matching(self):
        """인자에 따른 우선 매칭"""
        mock = MagicMock(spec=MessageService)

        def side_effect(to, msg):
            if to == "vip":
                return "priority"
            return "default"

        mock.send_message.side_effect = side_effect

        self.assertEqual("priority", mock.send_message("vip", "hello"))
        self.assertEqual("default", mock.send_message("normal", "hello"))

    def test_throw_exception(self):
        """예외 던지기"""
        mock = MagicMock(spec=MessageService)
        mock.send_message.side_effect = RuntimeError("network error")

        with self.assertRaises(RuntimeError) as ctx:
            mock.send_message("to", "msg")
        self.assertEqual("network error", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
