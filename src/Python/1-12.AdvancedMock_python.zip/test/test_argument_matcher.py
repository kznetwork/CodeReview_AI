import unittest
from unittest.mock import MagicMock, call

from src.message_service import MessageService


class TestArgumentMatcher(unittest.TestCase):
    """Argument Matchers – 인자 조건에 따른 동작 설정"""

    def test_starts_with_and_has_substr(self):
        """StartsWith + HasSubstr 매처 동등 구현"""
        mock = MagicMock(spec=MessageService)

        def side_effect(to, msg):
            if to.startswith("vip") and "urgent" in msg:
                return "matched"
            return "not matched"

        mock.send_message.side_effect = side_effect

        result = mock.send_message("vip_user", "urgent: help!")
        self.assertEqual("matched", result)

    def test_various_matchers(self):
        """Eq 매처 동등 구현"""
        mock = MagicMock(spec=MessageService)

        def side_effect(to, msg):
            if to == "admin":
                return "admin_response"
            return "default"

        mock.send_message.side_effect = side_effect

        result = mock.send_message("admin", "hello")
        self.assertEqual("admin_response", result)

        # 호출 인자 검증
        mock.send_message.assert_called_with("admin", "hello")


if __name__ == "__main__":
    unittest.main()
