import unittest
from unittest.mock import patch, MagicMock

from src.real_message_service import RealMessageService


class TestSpy(unittest.TestCase):
    """SPY – 실제 객체를 감싸서 일부 호출만 가로채기"""

    def test_partial_override(self):
        """특정 호출만 가로채고 나머지는 실제 호출로 위임"""
        spy = RealMessageService()

        original_send = spy.send_message

        def side_effect(to, msg):
            # 특정 호출만 가로채기
            if to == "to" and msg == "msg":
                return "fake"
            # 나머지는 실제 호출로 위임
            return original_send(to, msg)

        with patch.object(spy, "send_message", side_effect=side_effect):
            self.assertEqual("fake", spy.send_message("to", "msg"))
            self.assertEqual("real: hello", spy.send_message("other", "hello"))


if __name__ == "__main__":
    unittest.main()
