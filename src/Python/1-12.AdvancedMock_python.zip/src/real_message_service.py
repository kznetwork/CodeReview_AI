from src.message_service import MessageService


class RealMessageService(MessageService):
    """실제 메시지 서비스 구현"""

    def send_message(self, to: str, msg: str) -> str:
        return f"real: {msg}"
