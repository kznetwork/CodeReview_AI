from abc import ABC, abstractmethod


class MessageService(ABC):
    """메시지 서비스 인터페이스 (추상 클래스)"""

    @abstractmethod
    def send_message(self, to: str, msg: str) -> str:
        pass
