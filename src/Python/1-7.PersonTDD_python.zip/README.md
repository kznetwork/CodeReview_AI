# Person TDD - Python

Person 클래스의 TDD(Test-Driven Development) 예제 프로젝트입니다.

## 요구 사항

- Python 3.9 이상
- pytest

## 설치

```bash
pip install pytest
```

## 테스트 실행

```bash
pytest
```

상세 출력:

```bash
pytest -v
```

## 프로젝트 구조

```
├── pyproject.toml       # 프로젝트 설정
├── src/
│   └── person.py        # Person 클래스
└── test/
    └── test_person.py   # 테스트 코드
```
