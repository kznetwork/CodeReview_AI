import pytest
from src.person import Person


class TestPerson:
    def setup_method(self):
        self.person = Person("홍길동")

    def test_get_name(self):
        assert self.person.name == "홍길동"

    def test_set_name(self):
        self.person.name = "이순신"
        assert self.person.name == "이순신"

    def test_none_name_raises(self):
        with pytest.raises(ValueError):
            Person(None)
