# SOLID 원칙 Python 예제

객체지향 설계의 SOLID 원칙을 Python으로 구현한 예제 프로젝트입니다.

## 프로젝트 구조

```
src/python/
├── srp/          # 단일 책임 원칙 (Single Responsibility Principle)
├── ocp/          # 개방-폐쇄 원칙 (Open-Closed Principle)
├── lsp/          # 리스코프 치환 원칙 (Liskov Substitution Principle)
│   ├── lsp_violation/      # LSP 위반 예제
│   └── correcting_lsp/     # LSP 준수 예제
├── isp/          # 인터페이스 분리 원칙 (Interface Segregation Principle)
└── dip/          # 의존성 역전 원칙 (Dependency Inversion Principle)
```

## 가상환경 설정 및 실행 방법

### 1. 가상환경 생성

```bash
python -m venv venv
```

### 2. 가상환경 활성화

Windows (PowerShell):
```powershell
.\venv\Scripts\Activate.ps1
```

Windows (CMD):
```cmd
venv\Scripts\activate.bat
```

macOS / Linux:
```bash
source venv/bin/activate
```

### 3. 예제 실행

가상환경이 활성화된 상태에서 원하는 예제를 실행합니다.

```bash
python src/python/srp/SRPDemo.py
python src/python/ocp/OCPDemo.py
python src/python/lsp/lsp_violation/LSPDemo.py
python src/python/lsp/correcting_lsp/LSPDemo.py
python src/python/isp/ISPDemo.py
python src/python/dip/DIPDemo.py
```

### 4. 가상환경 비활성화

```bash
deactivate
```
