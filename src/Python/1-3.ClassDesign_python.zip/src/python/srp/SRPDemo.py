from enum import Enum


class Maker(Enum):
    FENDER = "FENDER"
    GIBSON = "GIBSON"


class Wood(Enum):
    MAHOGANY = "MAHOGANY"
    MAPLE = "MAPLE"


# 사양 클래스: 오직 기타의 물리적 특징만 담당
class GuitarSpec:
    def __init__(self, maker: Maker, model: str, top_wood: Wood, back_wood: Wood, string_num: int):
        self._maker = maker
        self._model = model
        self._top_wood = top_wood
        self._back_wood = back_wood
        self._string_num = string_num

    @property
    def maker(self) -> Maker:
        return self._maker

    @property
    def model(self) -> str:
        return self._model

    @property
    def top_wood(self) -> Wood:
        return self._top_wood

    @property
    def back_wood(self) -> Wood:
        return self._back_wood

    @property
    def string_num(self) -> int:
        return self._string_num


# 기타 클래스: 개별 악기의 정보와 변하는 상태(가격) 담당
class Guitar:
    def __init__(self, serial_number: str, price: float, spec: GuitarSpec):
        self._serial_number = serial_number
        self._price = price
        self._spec = spec

    @property
    def serial_number(self) -> str:
        return self._serial_number

    @property
    def price(self) -> float:
        return self._price

    @price.setter
    def price(self, new_price: float):
        self._price = new_price

    @property
    def spec(self) -> GuitarSpec:
        return self._spec


if __name__ == "__main__":
    # 사양 객체 생성
    strat_spec = GuitarSpec(Maker.FENDER, "Stratocaster", Wood.MAPLE, Wood.MAHOGANY, 6)

    # 개별 기타 객체 생성
    my_guitar = Guitar("V12345", 1500.0, strat_spec)

    print("--- 기타 정보 ---")
    print(f"시리얼 번호: {my_guitar.serial_number}")
    print(f"제조사: {my_guitar.spec.maker.value}")
    print(f"모델명: {my_guitar.spec.model}")
    print(f"상판 목재: {my_guitar.spec.top_wood.value}")
    print(f"후판 목재: {my_guitar.spec.back_wood.value}")
    print(f"줄 수: {my_guitar.spec.string_num}")
    print(f"현재 가격: ${my_guitar.price}")
