from enum import Enum


class Maker(Enum):
    FENDER = "FENDER"
    GIBSON = "GIBSON"
    MARTIN = "MARTIN"


class Wood(Enum):
    MAHOGANY = "MAHOGANY"
    MAPLE = "MAPLE"
    ALDER = "ALDER"
    ROSEWOOD = "ROSEWOOD"


class Guitar:
    def __init__(self, serial_number: str, price: float, maker: Maker,
                 model: str, top_wood: Wood, back_wood: Wood, string_num: int):
        self._serial_number = serial_number
        self._price = price
        self._maker = maker
        self._model = model
        self._top_wood = top_wood
        self._back_wood = back_wood
        self._string_num = string_num

    @property
    def serial_number(self) -> str:
        return self._serial_number

    @property
    def price(self) -> float:
        return self._price

    @property
    def maker(self) -> Maker:
        return self._maker

    @property
    def model(self) -> str:
        return self._model

    @property
    def top_wood(self) -> Wood:
        return self._top_wood

    @property
    def back_wood(self) -> Wood:
        return self._back_wood

    @property
    def string_num(self) -> int:
        return self._string_num


if __name__ == "__main__":
    guitar = Guitar("SN-001", 1500.0, Maker.FENDER,
                    "Stratocaster", Wood.MAPLE, Wood.ALDER, 6)

    print(f"Serial Number: {guitar.serial_number}")
    print(f"Price: {guitar.price}")
    print(f"Maker: {guitar.maker.value}")
    print(f"Model: {guitar.model}")
    print(f"Top Wood: {guitar.top_wood.value}")
    print(f"Back Wood: {guitar.back_wood.value}")
    print(f"String Number: {guitar.string_num}")
