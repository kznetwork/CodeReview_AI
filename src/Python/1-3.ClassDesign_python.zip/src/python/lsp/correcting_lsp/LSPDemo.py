from abc import ABC, abstractmethod


# 인터페이스: 날 수 있는 새
class Flyable(ABC):
    @abstractmethod
    def fly(self):
        pass


# 상위 클래스: Bird
class Bird:
    def eat(self):
        print("새가 먹이를 먹고 있습니다!")


# 하위 클래스: Sparrow (날 수 있음)
class Sparrow(Bird, Flyable):
    def fly(self):
        print("참새가 날고 있습니다!")


# 하위 클래스: Ostrich (날 수 없음)
class Ostrich(Bird):
    pass  # fly() 메서드를 구현하지 않음


# 헬퍼 함수
def make_bird_eat(bird: Bird):
    bird.eat()


def make_bird_fly(bird: Flyable):
    bird.fly()


# 메인 함수 - LSP 준수
if __name__ == "__main__":
    sparrow = Sparrow()
    ostrich = Ostrich()

    # 모든 새는 먹이를 먹을 수 있음
    make_bird_eat(sparrow)
    make_bird_eat(ostrich)

    # 날 수 있는 새만 Flyable 인터페이스를 사용
    make_bird_fly(sparrow)
