# 상위 클래스: Bird
class Bird:
    def fly(self):
        print("새가 날고 있습니다!")


# 하위 클래스: Sparrow (정상 동작)
class Sparrow(Bird):
    def fly(self):
        print("참새가 날고 있습니다!")


# 하위 클래스: Ostrich (날 수 없지만 fly 메서드 상속됨)
class Ostrich(Bird):
    def fly(self):
        raise RuntimeError("타조는 날 수 없습니다!")


# 헬퍼 함수
def make_bird_fly(bird: Bird):
    bird.fly()


# 메인 함수 - LSP 위반
if __name__ == "__main__":
    sparrow = Sparrow()
    ostrich = Ostrich()  # 타조는 Bird 타입으로 사용될 수 있음

    make_bird_fly(sparrow)  # 정상 출력

    try:
        make_bird_fly(ostrich)  # Runtime Exception 발생!
    except RuntimeError as e:
        print(f"예외 발생: {e}")
