from abc import ABC, abstractmethod


# 기본 동물 행동 인터페이스
class BasicAnimalActions(ABC):
    @abstractmethod
    def eat(self):
        pass

    @abstractmethod
    def sleep(self):
        pass


# 날 수 있는 동물을 위한 인터페이스
class FlyingAnimalActions(ABC):
    @abstractmethod
    def fly(self):
        pass


# 수영할 수 있는 동물을 위한 인터페이스
class SwimmingAnimalActions(ABC):
    @abstractmethod
    def swim(self):
        pass


# 새 클래스 (기본 행동 + 날기 구현)
class Bird(BasicAnimalActions, FlyingAnimalActions):
    def eat(self):
        print("새가 먹이를 먹고 있습니다.")

    def sleep(self):
        print("새가 잠을 자고 있습니다.")

    def fly(self):
        print("새가 날고 있습니다.")


# 물고기 클래스 (기본 행동 + 수영 구현)
class Fish(BasicAnimalActions, SwimmingAnimalActions):
    def eat(self):
        print("물고기가 먹이를 먹고 있습니다.")

    def sleep(self):
        print("물고기가 잠을 자고 있습니다.")

    def swim(self):
        print("물고기가 수영하고 있습니다.")


# 개 클래스 (기본 행동만 구현)
class Dog(BasicAnimalActions):
    def eat(self):
        print("개가 먹이를 먹고 있습니다.")

    def sleep(self):
        print("개가 잠을 자고 있습니다.")


# 메인 함수 - ISP 데모
if __name__ == "__main__":
    bird = Bird()
    fish = Fish()
    dog = Dog()

    # 공통 행동 실행
    bird.eat()
    bird.sleep()

    # 날 수 있는지 확인 후 실행
    if isinstance(bird, FlyingAnimalActions):
        bird.fly()

    fish.eat()
    fish.sleep()

    # 수영할 수 있는지 확인 후 실행
    if isinstance(fish, SwimmingAnimalActions):
        fish.swim()

    dog.eat()
    dog.sleep()
