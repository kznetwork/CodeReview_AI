from abc import ABC, abstractmethod


# 추상화: MessageService
class MessageService(ABC):
    @abstractmethod
    def send_message(self, message: str, recipient: str):
        pass


# 구체적인 구현 1: Email 서비스
class EmailService(MessageService):
    def send_message(self, message: str, recipient: str):
        print(f"이메일을 {recipient}에게 전송: {message}")


# 구체적인 구현 2: SMS 서비스
class SMSService(MessageService):
    def send_message(self, message: str, recipient: str):
        print(f"SMS를 {recipient}에게 전송: {message}")


# 상위 모듈: Notification
class Notification:
    def __init__(self, message_service: MessageService):
        # 의존성 주입 (생성자 주입)
        self._message_service = message_service

    def notify_user(self, message: str, recipient: str):
        self._message_service.send_message(message, recipient)


# 메인 함수 - DIP 데모
if __name__ == "__main__":
    # EmailService를 사용하는 경우
    email_service = EmailService()
    email_notification = Notification(email_service)
    email_notification.notify_user("이메일로 전송된 메시지입니다!", "john@example.com")

    # SMSService를 사용하는 경우
    sms_service = SMSService()
    sms_notification = Notification(sms_service)
    sms_notification.notify_user("SMS로 전송된 메시지입니다!", "010-1234-5678")
