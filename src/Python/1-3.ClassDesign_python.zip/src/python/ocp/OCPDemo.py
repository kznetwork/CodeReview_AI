import math
from abc import ABC, abstractmethod


# 추상 클래스: 도형의 기본 설계
class Shape(ABC):
    @abstractmethod
    def calculate_area(self) -> float:
        pass


# 사각형 클래스
class Rectangle(Shape):
    def __init__(self, width: float, height: float):
        self._width = width
        self._height = height

    def calculate_area(self) -> float:
        return self._width * self._height


# 원 클래스
class Circle(Shape):
    def __init__(self, radius: float):
        self._radius = radius

    def calculate_area(self) -> float:
        return math.pi * self._radius ** 2


# 삼각형 클래스
class Triangle(Shape):
    def __init__(self, base: float, height: float):
        self._base = base
        self._height = height

    def calculate_area(self) -> float:
        return 0.5 * self._base * self._height


# 메인 함수 - OCP 데모
if __name__ == "__main__":
    rectangle = Rectangle(5, 10)   # 사각형
    circle = Circle(7)             # 원
    triangle = Triangle(6, 8)      # 삼각형

    print(f"사각형 넓이: {rectangle.calculate_area()}")
    print(f"원 넓이: {circle.calculate_area()}")
    print(f"삼각형 넓이: {triangle.calculate_area()}")
