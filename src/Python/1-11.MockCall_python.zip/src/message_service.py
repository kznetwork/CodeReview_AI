from abc import ABC, abstractmethod


# 메시지 서비스 인터페이스
class MessageService(ABC):
    @abstractmethod
    def send_message(self, to: str, msg: str) -> str:
        pass
