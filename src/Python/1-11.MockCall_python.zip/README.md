# MockCall - Python Mock 테스트 예제

`unittest.mock`을 활용한 Mock / Stub / 호출 횟수 검증 예제 프로젝트입니다.

## 프로젝트 구조

```
├── requirements.txt
├── src/
│   └── message_service.py    # MessageService 인터페이스
└── test/
    ├── conftest.py           # pytest 경로 설정
    ├── test_mock.py          # Mock 행위 검증
    ├── test_stub.py          # Stub 반환값 설정
    └── test_times.py         # 호출 횟수 검증
```

## 가상환경 설정 및 실행

### 1. 가상환경 생성

```bash
python -m venv venv
```

### 2. 가상환경 활성화

**Windows (cmd)**
```cmd
venv\Scripts\activate.bat
```

**Windows (PowerShell)**
```powershell
venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source venv/bin/activate
```

### 3. 의존성 설치

```bash
pip install -r requirements.txt
```

### 4. 테스트 실행

```bash
python -m pytest test/ -v
```

### 5. 가상환경 비활성화

```bash
deactivate
```
