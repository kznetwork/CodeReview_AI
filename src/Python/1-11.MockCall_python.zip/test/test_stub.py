import unittest
from unittest.mock import MagicMock

from message_service import MessageService


# — Stub – 반환값 설정 ——————————
class TestStub(unittest.TestCase):
    def test_stub_example(self):
        stub = MagicMock(spec=MessageService)

        # 호출 시 반환값 지정 (행위 검증 없음)
        stub.send_message.return_value = "stubbed"

        # 어떤 인수로 호출해도 동일한 반환값
        result = stub.send_message("to", "msg")

        self.assertEqual("stubbed", result)


if __name__ == "__main__":
    unittest.main()
