import unittest
from unittest.mock import MagicMock

from message_service import MessageService


# — Mock – 행위 검증 ——————————
class TestMock(unittest.TestCase):
    def test_mock_example(self):
        mock = MagicMock(spec=MessageService)

        # 반환값 설정
        mock.send_message.return_value = "mocked"

        # 호출
        result = mock.send_message("to", "hello")

        # 반환값 검증
        self.assertEqual("mocked", result)

        # 호출 횟수·인수 검증
        mock.send_message.assert_called_once_with("to", "hello")


if __name__ == "__main__":
    unittest.main()
