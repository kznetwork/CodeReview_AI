import unittest
from unittest.mock import MagicMock, call

from message_service import MessageService


# — 다양한 호출 횟수 검증 ——————————
class TestTimes(unittest.TestCase):

    def test_any_number_of_times(self):
        """0회 이상 호출 허용"""
        mock = MagicMock(spec=MessageService)
        mock.send_message.return_value = "ok"

        mock.send_message("a", "b")
        mock.send_message("c", "d")

        # 호출 횟수 제한 없이 호출되었는지만 확인
        self.assertEqual(mock.send_message.call_count, 2)

    def test_at_least_once(self):
        """1회 이상 호출"""
        mock = MagicMock(spec=MessageService)
        mock.send_message.return_value = "ok"

        mock.send_message("a", "b")

        # 최소 1회 호출 검증
        self.assertGreaterEqual(mock.send_message.call_count, 1)
        mock.send_message.assert_called()

    def test_between_two_and_five(self):
        """2~5회 호출"""
        mock = MagicMock(spec=MessageService)
        mock.send_message.return_value = "ok"

        mock.send_message("a", "1")
        mock.send_message("b", "2")
        mock.send_message("c", "3")

        # 호출 횟수가 2~5 범위인지 검증
        count = mock.send_message.call_count
        self.assertGreaterEqual(count, 2)
        self.assertLessEqual(count, 5)

        # 호출 인수 목록 검증
        expected_calls = [
            call("a", "1"),
            call("b", "2"),
            call("c", "3"),
        ]
        mock.send_message.assert_has_calls(expected_calls)


if __name__ == "__main__":
    unittest.main()
