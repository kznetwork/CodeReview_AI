def main():
    a = 1
    if a == 1:
        print("hi")


if __name__ == "__main__":
    main()
