# 1-4. Clean Code (Python)

Python 코드 스타일을 검사하고 자동 포맷팅하는 방법을 다루는 프로젝트입니다.

## 요구 사항

- Python 3.x
- 코드 스타일 도구 설치:

```bash
pip install flake8 black
```

## 코드 스타일 검사 (Lint)

`flake8`을 사용하여 PEP 8 스타일 위반 사항을 확인합니다.

```bash
flake8 clang_test.py
```

## 코드 자동 포맷팅

`black`을 사용하여 코드를 자동으로 정리합니다.

```bash
black clang_test.py
```

## 예제 실행

```bash
python clang_test.py
```

## 참고

| 도구 | 역할 |
|------|------|
| `flake8` | PEP 8 스타일 검사 (lint) |
| `black` | 코드 자동 포맷팅 (formatter) |

기존 C++에서는 `.clang-format`과 `clang-format` 도구를 사용했지만, Python에서는 `flake8` + `black` 조합이 표준적인 코드 스타일 관리 방법입니다.
