# Hello Python

간단한 Python 프로젝트입니다.

## 가상 환경 설정 및 실행

### 1. 가상 환경 생성

```bash
python -m venv venv
```

### 2. 가상 환경 활성화

**Windows (cmd)**
```cmd
venv\Scripts\activate.bat
```

**Windows (PowerShell)**
```powershell
venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source venv/bin/activate
```

### 3. 프로그램 실행

```bash
python main.py
```

### 4. 테스트 실행

```bash
python -m unittest test_hello
```

### 5. 가상 환경 비활성화

```bash
deactivate
```
