from hello import get_hello_message


def main():
    print(get_hello_message())


if __name__ == "__main__":
    main()
