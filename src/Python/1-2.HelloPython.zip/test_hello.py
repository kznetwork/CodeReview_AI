import unittest

from hello import get_hello_message


class TestHello(unittest.TestCase):
    def test_returns_expected_message(self):
        self.assertEqual(get_hello_message(), "Hello, Python in VS Code!")

    def test_message_is_not_empty(self):
        self.assertTrue(len(get_hello_message()) > 0)


if __name__ == "__main__":
    unittest.main()
