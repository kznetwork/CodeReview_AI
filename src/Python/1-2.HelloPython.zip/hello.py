def get_hello_message() -> str:
    return "Hello, Python in VS Code!"
