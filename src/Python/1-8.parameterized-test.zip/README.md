# Parameterized Test Lab (Python)

pytest의 `@pytest.mark.parametrize`를 활용한 매개변수화 테스트 예제입니다.

## 프로젝트 구조

```
src/
  day_of_week.py      # 요일 Enum
  fruit_ranker.py     # 과일/등급 검증 클래스
  weekend_checker.py  # 주말 판별 클래스
test/
  test_parameterized.py  # 매개변수화 테스트
requirements.txt
```

## 실행 방법

### 1. 의존성 설치

```bash
pip install -r requirements.txt
```

### 2. 테스트 실행

```bash
pytest test/test_parameterized.py -v
```

### 3. 실행 결과

- 총 19개 테스트 중 18개 통과, 1개 의도적 실패
- `test_is_weekend_mixed[DayOfWeek.MONDAY]` — MONDAY는 주말이 아니므로 실패 (TDD 학습용 의도적 실패)
