"""
Parameterized Test (pytest)
"""
import pytest

from src.day_of_week import DayOfWeek
from src.weekend_checker import WeekendChecker
from src.fruit_ranker import FruitRanker


# ──────────────────────────────────────────────
# 1. 문자열 목록 — @ValueSource 대응
# ──────────────────────────────────────────────
@pytest.mark.parametrize("name", ["hong", "kim", "park"])
def test_name_is_not_empty(name: str):
    assert name  # 빈 문자열이 아닌지 확인


# ──────────────────────────────────────────────
# 2. Enum 전체 — @EnumSource 대응
# ──────────────────────────────────────────────
@pytest.mark.parametrize("day", list(DayOfWeek))
def test_day_of_week_all(day: DayOfWeek):
    # enum 값이므로 항상 유효
    assert isinstance(day, DayOfWeek)


# ──────────────────────────────────────────────
# 3. Enum 선택 — names 필터 (평일만)
# ──────────────────────────────────────────────
@pytest.mark.parametrize("day", [
    DayOfWeek.MONDAY,
    DayOfWeek.WEDNESDAY,
    DayOfWeek.FRIDAY,
])
def test_weekday_is_not_weekend(day: DayOfWeek):
    assert not WeekendChecker.is_weekend(day)


# ──────────────────────────────────────────────
# 4. CSV 다중 입력 — @CsvSource 대응
# ──────────────────────────────────────────────
@pytest.mark.parametrize("fruit,rank", [
    ("apple", 1),
    ("banana", 2),
    ("lemon, lime", 3),
])
def test_csv_source(fruit: str, rank: int):
    assert fruit  # 빈 문자열이 아닌지
    assert rank > 0


# ──────────────────────────────────────────────
# 5. 주말 판별 — 성공/실패 혼합
#    MONDAY 포함 → 의도적 실패 (TDD 학습용)
# ──────────────────────────────────────────────
@pytest.mark.parametrize("day", [
    DayOfWeek.SATURDAY,
    DayOfWeek.MONDAY,   # ⚠ 의도적 실패
    DayOfWeek.SUNDAY,
])
def test_is_weekend_mixed(day: DayOfWeek):
    # ⚠ MONDAY가 포함돼 테스트 실패 → 의도된 것
    # → WeekendChecker 로직 점검 기회
    assert WeekendChecker.is_weekend(day)
