"""
주어진 요일이 주말(SATURDAY, SUNDAY)인지 판별
"""
from src.day_of_week import DayOfWeek


class WeekendChecker:
    @staticmethod
    def is_weekend(day: DayOfWeek) -> bool:
        return day in (DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
