"""
과일과 등급 검증 (null·빈 값·양수 체크)
"""


class FruitRanker:
    def __init__(self, fruit: str, rank: int):
        self._fruit = fruit
        self._rank = rank

    @property
    def fruit(self) -> str:
        return self._fruit

    @property
    def rank(self) -> int:
        return self._rank

    def is_valid(self) -> bool:
        return bool(self._fruit) and self._rank > 0
