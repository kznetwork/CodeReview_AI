# Arithmetic

간단한 사칙연산 계산기 프로그램입니다.

## 프로젝트 구조

```
src/
  arithmetic_operations.py   # 사칙연산 클래스
  main.py                    # 메인 프로그램
test/
  test_arithmetic_operations.py  # 테스트
```

## 가상 환경 설정 및 실행

### 1. 가상 환경 생성

```bash
python -m venv venv
```

### 2. 가상 환경 활성화

**Windows (CMD)**
```cmd
venv\Scripts\activate.bat
```

**Windows (PowerShell)**
```powershell
venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source venv/bin/activate
```

### 3. 프로그램 실행

```bash
python src/main.py
```

### 4. 테스트 실행

```bash
python test/test_arithmetic_operations.py
```

### 5. 가상 환경 비활성화

```bash
deactivate
```
