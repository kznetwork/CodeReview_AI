import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from arithmetic_operations import ArithmeticOperations


def test_addition():
    ao = ArithmeticOperations()
    assert ao.addition(4, 2) == 6
    print("test_addition passed")


def test_subtraction():
    ao = ArithmeticOperations()
    assert ao.subtraction(4, 2) == 2
    print("test_subtraction passed")


def test_multiplication():
    ao = ArithmeticOperations()
    assert ao.multiplication(4, 2) == 8
    print("test_multiplication passed")


def test_division():
    ao = ArithmeticOperations()
    assert ao.division(4, 2) == 2
    print("test_division passed")


if __name__ == "__main__":
    test_addition()
    test_subtraction()
    test_multiplication()
    test_division()
    print("All tests passed!")
