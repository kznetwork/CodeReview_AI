class ArithmeticOperations:
    def addition(self, x: int, y: int) -> int:
        return x + y

    def subtraction(self, x: int, y: int) -> int:
        return x - y

    def multiplication(self, x: int, y: int) -> int:
        return x * y

    def division(self, x: int, y: int) -> int:
        return x // y

    def quotient(self, x: int, y: int) -> float:
        return x / y
