from arithmetic_operations import ArithmeticOperations


def main():
    ao = ArithmeticOperations()

    num1 = int(input("첫번째 정수값 >>"))
    op = input("연산자 >>")
    num2 = int(input("두번째 정수 값 >>"))

    print("================================================")
    print(f"{num1} {op} {num2}을 계산합니다.")
    print("================================================")

    if op == "+":
        result = ao.addition(num1, num2)
        print(f"{num1}+{num2}={result}입니다.")
    elif op == "-":
        result = ao.subtraction(num1, num2)
        print(f"{num1}-{num2}={result}입니다.")
    elif op == "*":
        result = ao.multiplication(num1, num2)
        print(f"{num1}*{num2}={result}입니다.")
    elif op == "/":
        result = ao.quotient(num1, num2)
        print(f"연산의 결과는{num1}/{num2}={result}입니다.")
    else:
        print("정확하게 정수와 연산자를 입력해주세요.")


if __name__ == "__main__":
    main()
