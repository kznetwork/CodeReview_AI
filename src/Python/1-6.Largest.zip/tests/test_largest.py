import pytest
from largest import largest


def test_simple():
    assert largest([7, 8, 9]) == 9


def test_order():
    assert largest([7, 9, 8]) == 9
    assert largest([9, 8, 7]) == 9
    assert largest([9, 7, 9, 8]) == 9


def test_single_value():
    assert largest([1]) == 1


def test_negative_values():
    assert largest([-9, -8, -7]) == -7


def test_empty_list():
    with pytest.raises(ValueError, match="Empty List"):
        largest([])
