# Largest

리스트에서 가장 큰 값을 찾는 프로그램입니다.

## 실행 방법

```bash
python main.py
```

## 테스트 실행

```bash
pip install pytest
python -m pytest tests/
```
