from largest import largest


def main():
    numbers = [7, 8, 9]
    print(f"Largest value: {largest(numbers)}")


if __name__ == "__main__":
    main()
