def largest(numbers: list[int]) -> int:
    """리스트에서 가장 큰 값을 반환한다."""
    if not numbers:
        raise ValueError("Empty List")
    return max(numbers)
