class CalcSample:
    @staticmethod
    def sum(a: int, b: int) -> int:
        return a + b
