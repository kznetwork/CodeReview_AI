# CalcSample TDD - Python

간단한 계산기 클래스의 TDD(테스트 주도 개발) 예제 프로젝트입니다.

## 프로젝트 구조

```
├── pyproject.toml
├── src/
│   └── calc_sample.py
└── test/
    └── test_calc_sample.py
```

## 요구사항

- Python 3.9 이상
- pytest

## pytest 설치

```bash
pip install pytest
```

## 테스트 실행

```bash
pytest test/ -v
```

## 실행 예시

```python
from src.calc_sample import CalcSample

result = CalcSample.sum(1, 2)
print(result)  # 3
```
