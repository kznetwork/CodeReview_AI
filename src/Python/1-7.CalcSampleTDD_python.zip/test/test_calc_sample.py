import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from calc_sample import CalcSample


def test_plus_basic():
    assert CalcSample.sum(1, 2) == 3
    assert CalcSample.sum(4, 1) == 5


# 매개변수화 버전
@pytest.mark.parametrize("a, b, expected", [
    (1, 2, 3),
    (4, 1, 5),
])
def test_sum_parametrized(a, b, expected):
    assert CalcSample.sum(a, b) == expected
