# ❌ 냄새 6 — 가변 데이터
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

p = Point(0, 0)
p.x = 10  # 어디서든 변경 가능 → 추적 어려움


# ✅ After 1 — 불변 값 객체 (NamedTuple / frozen dataclass)
# from dataclasses import dataclass
#
# @dataclass(frozen=True)
# class ImmutablePoint:
#     x: int
#     y: int
# # 변경 대신 새 객체 생성


# ✅ After 2 — 변수 쪼개기 (Split Variable): 용도별 다른 변수 사용
# Before:
height, width = 5, 3
temp = 2 * (height + width)  # 둘레
temp = height * width         # 면적 (재사용 → 혼란!)
# After:
# perimeter = 2 * (height + width)
# area = height * width


# ✅ After 3 — 질의/변경 함수 분리
# 읽기와 쓰기를 항상 분리!
# class Counter:
#     def __init__(self):
#         self._count = 0
#
#     def get_total_count(self):  # 질의만
#         return self._count
#
#     def increment(self):  # 변경만
#         self._count += 1
