# 리팩토링 연습 - Python

마틴 파울러의 「리팩터링 2판」에 나오는 24가지 코드 냄새를 Python 예제로 정리한 프로젝트입니다.

## 가상환경 설정 및 실행

### 1. 가상환경 생성

```bash
python -m venv venv
```

### 2. 가상환경 활성화

**Windows (CMD)**
```cmd
venv\Scripts\activate.bat
```

**Windows (PowerShell)**
```powershell
venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source venv/bin/activate
```

### 3. 의존성 설치 (필요 시)

```bash
pip install -r requirements.txt
```

### 4. 예제 실행

```bash
python "냄새 1. 이해하기 힘든 이름 (Mysterious Name).py"
```

### 5. 가상환경 비활성화

```bash
deactivate
```

## 파일 목록

| # | 냄새 | 파일명 |
|---|------|--------|
| 1 | 이해하기 힘든 이름 | `냄새 1. 이해하기 힘든 이름 (Mysterious Name).py` |
| 2 | 중복 코드 | `냄새 2. 중복 코드 (Duplicated Code).py` |
| 3 | 긴 함수 | `냄새 3. 긴 함수 (Long Function).py` |
| 4 | 긴 매개변수 목록 | `냄새 4. 긴 매개변수 목록 (Long Parameter List).py` |
| 5 | 전역 데이터 | `냄새 5. 전역 데이터.py` |
| 6 | 가변 데이터 | `냄새 6. 가변 데이터 (Global & Mutable Data).py` |
| 7 | 뒤엉킨 변경 | `냄새 7. 뒤엉킨 변경(Divergent Change ).py` |
| 8 | 산탄총 수술 | `냄새 8. 산탄총 수술 (Shotgun Surgery).py` |
| 9 | 기능 편애 | `냄새 9. 기능 편애 (Feature Envy).py` |
| 10 | 데이터 뭉치 | `냄새 10. 데이터 뭉치 (Data Clumps).py` |
| 11 | 기본형 집착 | `냄새 11. 기본형 집착 (Primitive Obsession).py` |
| 12 | 반복되는 Switch | `냄새 12. 반복되는 Switch (Repeated Switches).py` |
| 13 | 반복문 | `냄새 13. 반복문 (Loops).py` |
| 14 | 성의 없는 요소 | `냄새 14. 성의 없는 요소.py` |
| 15 | 추측성 일반화 | `냄새 15. 추측성 일반화.py` |
| 16 | 임시 필드 | `냄새 16. 임시 필드.py` |
| 17 | 메시지 체인 | `냄새 17. 메시지 체인 (Message Chains).py` |
| 18 | 중재자 | `냄새 18. 중재자 (Middle Man).py` |
| 19 | 내부자 거래 | `냄새 19. 내부자 거래 (Insider Trading ).py` |
| 20 | 거대한 클래스 | `냄새 20. 거대한 클래스 (Large Class).py` |
| 21 | 서로 다른 대안 클래스들 | `냄새 21. 서로 다른 대안 클래스들 (Alternative Classes).py` |
| 22 | 데이터 클래스 | `냄새 22. 데이터 클래스 (Data Class).py` |
| 23 | 상속 포기 | `냄새 23. 상속 포기 (Refused Bequest).py` |
| 24 | 주석 | `냄새 24. 주석 (Comments).py` |

## 각 파일 구조

- **❌ Before** — 리팩토링 전 냄새가 나는 코드 (실행 가능)
- **✅ After** — 리팩토링 후 개선된 코드 (주석 처리)
