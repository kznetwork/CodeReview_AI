# ❌ 냄새 13 — 고전적 반복문
names = []
for emp in employees:
    if emp.office == "London":
        names.append(emp.name)


# ✅ After — 파이프라인으로 바꾸기 (리스트 컴프리헨션 / generator)
# names = [emp.name for emp in employees if emp.office == "London"]
