# ❌ 냄새 7 — 하나의 클래스가 DB도 하고 가격 계산도
class Order:
    def save_to_database(self):
        ...  # DB 역할

    def load_from_database(self):
        ...

    def calculate_discount(self):
        ...  # 가격 계산 역할

    def apply_tax(self, price):
        ...

# DB 변경할 때도, 가격 정책 바꿀 때도 이 클래스 수정!


# ✅ After — 단계 쪼개기 / 클래스 추출
# class OrderRepository:  # DB 전담
#     def save(self, order):
#         ...
#
#     def load(self, order_id):
#         ...
#
# class PricingEngine:  # 가격 전담
#     def discount(self, order):
#         ...
#
#     def apply_tax(self, price):
#         ...
