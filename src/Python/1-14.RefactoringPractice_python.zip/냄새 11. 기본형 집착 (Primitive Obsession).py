# ❌ 냄새 11 — 기본형으로 의미 있는 개념 표현
price = 19.99  # 그냥 float — 음수 방지 로직 어디?


# ✅ After 1 — 기본형을 객체로 바꾸기 (Replace Primitive with Object)
# class Price:
#     def __init__(self, value: float):
#         if value < 0:
#             raise ValueError("Price cannot be negative")
#         self._value = value
#
#     @property
#     def value(self):
#         return self._value
#
#     def __str__(self):
#         return f"${self._value:.2f}"


# ✅ After 2 — 타입 코드를 서브클래스로 바꾸기
# Before: type = 1(Engineer) / 2(Manager)
# After:
# from abc import ABC, abstractmethod
#
# class Employee(ABC):
#     @abstractmethod
#     def bonus(self, salary: float) -> float:
#         pass
#
# class Engineer(Employee):
#     def bonus(self, salary):
#         return salary * 0.1
#
# class Manager(Employee):
#     def bonus(self, salary):
#         return salary * 0.2
