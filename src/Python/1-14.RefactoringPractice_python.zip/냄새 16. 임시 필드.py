# ❌ 냄새 16 — 조건에 따라 의미 없는 필드
class Order:
    def __init__(self):
        self.customer_name = ""
        self.shipping_address = ""
        # 인터넷 주문일 때만 유효 — 매장 주문이면 항상 empty!
        self.tracking_number = ""


# ✅ After — 특이 케이스 클래스 추출
# from abc import ABC, abstractmethod
#
# class Order(ABC):
#     def __init__(self, customer_name):
#         self.customer_name = customer_name
#
#     @abstractmethod
#     def requires_shipping(self) -> bool:
#         pass
#
# class OnlineOrder(Order):
#     def __init__(self, customer_name, shipping_address, tracking_number):
#         super().__init__(customer_name)
#         self.shipping_address = shipping_address  # 온라인 전용
#         self.tracking_number = tracking_number
#
#     def requires_shipping(self):
#         return True
#
# class StoreOrder(Order):
#     def requires_shipping(self):
#         return False
