# ❌ Before — 모든 로직이 한 함수에
def process_order(order):
    # 유효성 검사
    if not order.items:
        return
    if order.customer_id < 0:
        return
    # 금액 계산
    total = 0
    for item in order.items:
        total += item.price * item.qty
    discount = total * 0.1 if total > 100 else 0
    total -= discount
    # 결제 처리
    pg = PaymentGateway()
    pg.charge(order.customer_id, total)
    # 알림 발송
    es = EmailService()
    es.send_confirmation(order.customer_id, total)


# ✅ After — 함수 추출 (Extract Function)
# def is_valid_order(order):
#     return bool(order.items) and order.customer_id >= 0
#
# def calculate_total(order):
#     total = sum(item.price * item.qty for item in order.items)
#     discount = total * 0.1 if total > 100 else 0
#     return total - discount
#
# def charge_payment(customer_id, total):
#     PaymentGateway().charge(customer_id, total)
#
# def send_notification(customer_id, total):
#     EmailService().send_confirmation(customer_id, total)
#
# def process_order(order):
#     if not is_valid_order(order):
#         return
#     total = calculate_total(order)
#     charge_payment(order.customer_id, total)
#     send_notification(order.customer_id, total)
