# ❌ Before — 매개변수 4개 이상은 위험 신호
def create_order(customer_name, address, city, zip_code,
                 price, quantity, payment_method):
    ...


# ✅ After 1: 매개변수 객체 만들기
# from dataclasses import dataclass
#
# @dataclass
# class Address:
#     street: str
#     city: str
#     zip_code: str
#
# @dataclass
# class OrderInfo:
#     customer_name: str
#     address: Address
#     price: float
#     quantity: int
#     payment_method: str
#
# def create_order(info: OrderInfo):
#     ...


# ✅ After 2: 객체 통째로 넘기기 (Preserve Whole Object)
# Before:
def set_range(low, high):
    ...

low = range_obj.get_low()
high = range_obj.get_high()
set_range(low, high)

# After:
# def set_range(range_obj):
#     # low = range_obj.get_low(), high = range_obj.get_high() 직접 사용
#     ...
# set_range(range_obj)  # 객체를 통째로 전달


# ✅ After 3: 매개변수를 질의 함수로 바꾸기
# Before: def discount(price, tax_rate): ...
# After:
# def discount(price):
#     return price * get_tax_rate()
