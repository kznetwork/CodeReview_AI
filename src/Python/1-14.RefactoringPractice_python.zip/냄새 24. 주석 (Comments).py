# ❌ 냄새 24 — 주석이 코드를 설명해야 하는 경우
# 두 조건이 모두 참이어야 배너를 렌더링함 (Mac + IE + 초기화됨 + 크기 변경됨)
if ("MAC" in platform and
    "IE" in browser and
    was_initialized and
    resize > 0):
    ...


# ✅ After — 변수 추출 (Extract Variable) → 주석 불필요
# is_mac_os = "MAC" in platform
# is_ie = "IE" in browser
# was_resized = resize > 0
# if is_mac_os and is_ie and was_initialized and was_resized:
#     ...


# ✅ Introduce Assertion — 가정을 코드로
# NULL_EXPENSE = -1
#
# def get_expense_limit(expense_limit, primary_project):
#     assert expense_limit != NULL_EXPENSE or primary_project is not None
#     if expense_limit != NULL_EXPENSE:
#         return expense_limit
#     return primary_project.get_member_expense_limit()
