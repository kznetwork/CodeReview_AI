# ❌ 냄새 23 — 상속 포기: MyStack이 list 기능 모두 상속받는 문제
class MyStack(list):
    # push/pop 기능만 필요한데 list의 모든 것이 상속됨!
    # insert, remove 등 스택에 부적절한 메서드도 노출
    pass


# ✅ After — 위임으로 교체 (Replace Inheritance with Delegation)
# class MyStack:
#     def __init__(self):
#         self._data = []  # 상속 → 위임!
#
#     def push(self, val):
#         self._data.append(val)
#
#     def top(self):
#         return self._data[-1]
#
#     def pop(self):
#         return self._data.pop()
#
#     def is_empty(self):
#         return len(self._data) == 0
#     # list의 다른 메서드는 노출 안 됨


# ✅ Extract Superclass — 공통 부분을 부모로
# from abc import ABC, abstractmethod
#
# class Party(ABC):
#     def __init__(self, name):
#         self._name = name
#
#     @abstractmethod
#     def annual_cost(self) -> int:
#         pass
#
#     @property
#     def name(self):
#         return self._name
#
# class Employee(Party):
#     def __init__(self, name, salary):
#         super().__init__(name)
#         self._salary = salary
#
#     def annual_cost(self):
#         return self._salary
#
# class Department(Party):
#     def __init__(self, name, staff):
#         super().__init__(name)
#         self._staff = staff
#
#     def annual_cost(self):
#         return sum(e.annual_cost() for e in self._staff)
