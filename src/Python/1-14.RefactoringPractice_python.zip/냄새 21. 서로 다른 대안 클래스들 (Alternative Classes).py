# ❌ 냄새 21 — 같은 역할인데 인터페이스가 다름
class EmailSender:
    def send_email(self, to, body):
        ...

class SMSSender:
    def transmit(self, num, msg):
        ...
    # send_email vs transmit — 같은 역할, 다른 이름!


# ✅ After — 인터페이스 통일 (슈퍼클래스 추출)
# from abc import ABC, abstractmethod
#
# class Notifier(ABC):
#     @abstractmethod
#     def send(self, recipient: str, message: str):
#         pass
#
# class EmailNotifier(Notifier):
#     def send(self, to, msg):
#         ...
#
# class SMSNotifier(Notifier):
#     def send(self, num, msg):
#         ...
