# ❌ Before — Invoice가 Address 데이터를 과도하게 사용 (기능 편애)
class Address:
    def __init__(self, street, city, zip_code):
        self.street = street
        self.city = city
        self.zip_code = zip_code


class Customer:
    def __init__(self, name, address):
        self.name = name
        self.address = address


class Invoice:
    def print_customer_info(self, customer):
        # Address의 데이터를 Invoice가 직접 조합 → 기능 편애!
        print(f"{customer.address.street}, "
              f"{customer.address.city} "
              f"{customer.address.zip_code}")


# ✅ After — format() 를 Address로 이동 (Move Function)
# class Address:
#     def __init__(self, street, city, zip_code):
#         self.street = street
#         self.city = city
#         self.zip_code = zip_code
#
#     def format(self):
#         # 책임이 Address에 있는 것이 자연스러움
#         return f"{self.street}, {self.city} {self.zip_code}"
#
# class Invoice:
#     def print_customer_info(self, customer):
#         print(customer.address.format())
#         # Invoice는 단순히 메시지만 전달
