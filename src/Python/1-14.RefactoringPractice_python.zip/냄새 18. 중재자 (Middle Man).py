# ❌ 냄새 18 — 중재자 (모든 메서드가 위임만)
class Person:
    def __init__(self, dept):
        self._dept = dept

    def get_manager(self):  # 위임만
        return self._dept.get_manager()

    def num_reports(self):  # 위임만
        return self._dept.num_reports()
    # Person이 하는 일이 없음!


# ✅ After — 중재자 제거 (Remove Middle Man)
# Person을 거치지 않고 dept에 직접 접근
# person.dept.get_manager()  — 또는:
# class Person:
#     def __init__(self, dept):
#         self.dept = dept  # public으로 노출


# ✅ After — 상속 대신 위임으로 (Replace Superclass with Delegate)
# Before: AdvancedPrinter(Printer) 불필요한 상속
import time

class AdvancedPrinter:
    def __init__(self, printer):
        self._printer = printer  # 위임!

    def print_msg(self, msg):
        self._printer.print_msg(msg)  # 위임

    def print_with_timestamp(self, msg):
        ts = time.time()
        print(f"[{ts}] {msg}")
