# ❌ 냄새 22 — 데이터 클래스 (getter/setter만 있는 클래스)
class Department:
    def __init__(self):
        self._name = ""
        self._staff = []
        self._student_count = 0

    def get_name(self):
        return self._name

    def set_name(self, n):
        self._name = n

    def get_staff(self):
        return self._staff

    def set_staff(self, s):
        self._staff = s
    # 관련 행위가 전혀 없음!


# ✅ After — 행위를 클래스로 이동 + setter 제거 + 컬렉션 캡슐화
# class Department:
#     def __init__(self, name):
#         self._name = name
#         self._staff = []
#
#     @property
#     def name(self):  # setter 제거 (불변)
#         return self._name
#
#     def add_employee(self, employee):  # 캡슐화
#         self._staff.append(employee)
#
#     def head_count(self):  # 행위 추가
#         return len(self._staff)
#
#     def total_salary(self):
#         return sum(e.salary for e in self._staff)
