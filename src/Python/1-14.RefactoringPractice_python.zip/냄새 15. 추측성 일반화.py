# ❌ 냄새 15 — 미래를 위해 만든 불필요한 추상화
from abc import ABC, abstractmethod

class AbstractDataProcessor(ABC):
    @abstractmethod
    def process(self):  # 구현체가 딱 하나뿐!
        pass

    def pre_process(self):  # 아무도 안 씀
        pass

    def post_process(self):
        pass

# ✅ After — 추상 클래스 제거, 구체 클래스 직접 사용
# 죽은 코드 제거 (Remove Dead Code)
