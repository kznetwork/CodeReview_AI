# ❌ 냄새 20 — 거대한 클래스 (너무 많은 책임)
class Person:
    def __init__(self):
        self.name = ""
        self.email = ""
        self.street = ""
        self.city = ""
        self.zip = ""           # 주소 정보
        self.card_number = ""
        self.expiry = ""        # 결제 정보
        self.username = ""
        self.password = ""      # 인증 정보

    def validate_email(self):
        ...

    def process_payment(self):
        ...

    def authenticate(self):
        ...
    # ... 수십 개의 메서드


# ✅ After — 클래스 추출 (Extract Class)
# from dataclasses import dataclass
#
# @dataclass
# class ContactInfo:
#     email: str
#     def validate(self): ...
#
# @dataclass
# class Address:
#     street: str
#     city: str
#     zip_code: str
#
# @dataclass
# class Payment:
#     card_number: str
#     expiry: str
#     def process(self): ...
#
# @dataclass
# class Auth:
#     username: str
#     password: str
#     def authenticate(self) -> bool: ...
#
# class Person:
#     def __init__(self, name, contact, address, payment, auth):
#         self.name = name
#         self.contact = contact
#         self.address = address
#         self.payment = payment
#         self.auth = auth
#     # 각 책임이 분리됨
