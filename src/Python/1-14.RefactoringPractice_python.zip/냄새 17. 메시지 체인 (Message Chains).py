# ❌ 냄새 17 — 긴 메시지 체인 (Law of Demeter 위반)
# 내부 구조에 강하게 결합!
dept = company.get_head().get_department().get_head().get_name()


# ✅ After — 위임 숨기기 (Hide Delegate)
# Company 클래스에 편의 메서드 추가
# class Company:
#     def get_department_head_name(self):
#         return self._head.get_department().get_head().get_name()
#
# # 사용처:
# dept = company.get_department_head_name()
