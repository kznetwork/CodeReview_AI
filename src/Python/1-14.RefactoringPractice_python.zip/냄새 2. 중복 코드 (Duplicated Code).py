# ❌ Before — 동일 로직이 두 곳에 중복
class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def get_area(self):
        return self.width * self.height

    def get_scale(self):
        return self.width * self.height * 2  # width * height 가 중복!


class Triangle:
    def __init__(self, base, height):
        self.base = base
        self.height = height

    def area(self):
        return 0.5 * self.base * self.height

    def info(self):
        return 0.5 * self.base * self.height  # 중복!


# ✅ After — 함수 추출하기 (Extract Function)
# class Rectangle:
#     def __init__(self, width, height):
#         self.width = width
#         self.height = height
#
#     def _compute_area(self):  # 추출
#         return self.width * self.height
#
#     def get_area(self):
#         return self._compute_area()
#
#     def get_scale(self):
#         return self._compute_area() * 2


# ✅ 클래스 계층에서 중복 — 함수 올리기 (Pull Up Method)
# from abc import ABC, abstractmethod
#
# class Shape(ABC):
#     @abstractmethod
#     def area(self) -> float:
#         pass
#
#     def print_area(self):  # 공통 → 부모로 올리기
#         print(f"Area: {self.area()}")
#
# class Rect(Shape):
#     def __init__(self, w, h):
#         self.w, self.h = w, h
#     def area(self):
#         return self.w * self.h
#
# class Tri(Shape):
#     def __init__(self, b, h):
#         self.b, self.h = b, h
#     def area(self):
#         return 0.5 * self.b * self.h
