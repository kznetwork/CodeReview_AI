# ❌ 냄새 8 — 세금 정책 변경 시 여러 클래스 수정 필요
class Order:
    def tax(self):
        return self.price * 0.1

class Receipt:
    def tax(self):
        return self.amount * 0.1

class Invoice:
    def tax(self):
        return self.total * 0.1

# 세율 0.1 → 0.12로 바꾸면? 3곳 모두 수정!


# ✅ After — 함수 옮기기 (Move Function)
# class TaxCalculator:
#     TAX_RATE = 0.1
#
#     @staticmethod
#     def calculate(amount):
#         return amount * TaxCalculator.TAX_RATE
#
# class Order:
#     def tax(self):
#         return TaxCalculator.calculate(self.price)
#
# class Receipt:
#     def tax(self):
#         return TaxCalculator.calculate(self.amount)
