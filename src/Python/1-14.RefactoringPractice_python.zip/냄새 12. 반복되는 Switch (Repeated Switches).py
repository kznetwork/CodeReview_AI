# ❌ 냄새 12 — switch가 여러 곳에 반복
# 새 타입 추가 시 모든 분기 수정 필요!
def calc_bonus(employee_type, salary):
    if employee_type == "ENGINEER":
        return salary * 0.1
    elif employee_type == "MANAGER":
        return salary * 0.2
    else:
        raise ValueError("unknown")


def describe(employee_type):
    if employee_type == "ENGINEER":  # 또 분기!
        return "Engineer"
    elif employee_type == "MANAGER":
        return "Manager"


# ✅ After — 다형성으로 교체 (Replace Conditional with Polymorphism)
# from abc import ABC, abstractmethod
#
# class Employee(ABC):
#     @abstractmethod
#     def bonus(self, salary: float) -> float:
#         pass
#
#     @abstractmethod
#     def describe(self) -> str:
#         pass
#
# class Engineer(Employee):
#     def bonus(self, salary):
#         return salary * 0.1
#
#     def describe(self):
#         return "Engineer"
#
# class Manager(Employee):
#     def bonus(self, salary):
#         return salary * 0.2
#
#     def describe(self):
#         return "Manager"
