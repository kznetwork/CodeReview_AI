# ❌ 냄새 5 — 전역 데이터
g_current_temperature = 0  # 전역 → 어디서든 변경 가능!

def set_temp(t):
    global g_current_temperature
    g_current_temperature = t


# ✅ After — 변수 캡슐화하기 (Encapsulate Variable)
# class TemperatureManager:
#     def __init__(self):
#         self._temperature = 0
#
#     @property
#     def temperature(self):
#         return self._temperature
#
#     @temperature.setter
#     def temperature(self, t):
#         self._temperature = t
