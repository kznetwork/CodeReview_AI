# ❌ 냄새 10 — 항상 같이 다니는 데이터 → 클래스로 묶기
# Before: 전화번호 3개가 항상 함께 전달
def print_phone(area_code, prefix, number):
    ...


# ✅ After — 클래스 추출하기 (Extract Class)
# class PhoneNumber:
#     def __init__(self, area_code, prefix, number):
#         self.area_code = area_code
#         self.prefix = prefix
#         self.number = number
#
#     def format(self):
#         return f"({self.area_code}) {self.prefix}-{self.number}"
#
# def print_phone(phone: PhoneNumber):
#     print(phone.format())
