# ❌ 냄새 19 — 내부자 거래 (결합도 과도)
class Department:
    def __init__(self):
        self._boss = None  # private

class Payroll:
    def process(self, dept):
        # dept._boss 직접 접근 → 강한 결합!
        print(dept._boss.salary)


# ✅ After — Hide Delegate: 인터페이스 제공
# class Department:
#     def __init__(self, boss):
#         self._boss = boss
#
#     def get_boss_salary(self):
#         return self._boss.salary
#
# class Payroll:
#     def process(self, dept):
#         print(dept.get_boss_salary())  # 공개 인터페이스 사용
