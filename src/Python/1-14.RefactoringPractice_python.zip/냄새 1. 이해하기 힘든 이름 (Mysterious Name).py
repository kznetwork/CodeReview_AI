# ❌ Before — 이름만 봐서는 의도를 알 수 없음
def calc(x, y):
    return x + y

class U:
    def __init__(self):
        self.nm = ""  # 무슨 뜻?
        self.ag = 0


# ✅ After — 이름만으로 의도 전달
# def calculate_total_price(base_price, tax):
#     return base_price + tax
#
# class User:
#     def __init__(self, name: str, age: int):
#         self.name = name
#         self.age = age
