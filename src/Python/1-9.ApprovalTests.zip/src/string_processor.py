"""입력 문자열의 단어들을 정렬하여 반환하는 모듈."""


def process(input_str: str) -> str:
    """입력 문자열의 단어들을 정렬하여 반환."""
    words = input_str.split()
    words.sort()
    return " ".join(words)
