# ApprovalTests Demo (Python)

입력 문자열의 단어들을 정렬하는 간단한 프로젝트입니다.  
Python용 [ApprovalTests](https://github.com/approvals/ApprovalTests.Python) 라이브러리를 활용한 테스트 예제를 포함합니다.

## 프로젝트 구조

```
src/
  string_processor.py      # 단어 정렬 함수
test/
  test_string_processor.py # 정렬 기능 Approval 테스트
  test_person.py           # 컬렉션 Approval 테스트
requirements.txt           # 의존성 목록
pytest.ini                 # pytest 설정
```

## 요구사항

- Python 3.8 이상

## 설치

```bash
pip install -r requirements.txt
```

## 테스트 실행

```bash
pytest
```

특정 테스트만 실행:

```bash
pytest test/test_string_processor.py
pytest test/test_person.py
```

상세 출력:

```bash
pytest -v
```
