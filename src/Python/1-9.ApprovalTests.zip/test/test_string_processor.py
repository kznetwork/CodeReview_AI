"""StringProcessor에 대한 Approval 테스트."""

from approvaltests import verify
from string_processor import process


def test_sort_words():
    input_str = "banana apple Orange Grape"
    result = process(input_str)
    verify(result)
    # → test_string_processor.test_sort_words.approved.txt 와 비교
