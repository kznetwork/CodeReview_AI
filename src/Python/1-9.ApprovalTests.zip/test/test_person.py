"""컬렉션 Approval 테스트."""

from approvaltests import verify_all


def test_approve_list():
    names = ["Alice", "Bob", "Charlie"]
    verify_all("Names", names)
    # approved.txt:
    # Names[0] = Alice
    # Names[1] = Bob
    # Names[2] = Charlie
