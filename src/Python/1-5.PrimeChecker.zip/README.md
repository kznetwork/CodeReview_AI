# PrimeChecker

주어진 숫자가 소수인지 판별하는 Python 프로그램입니다.

## 요구사항

- Python 3.x

## 실행 방법

```bash
py main.py
```

## 테스트 실행

```bash
py tests/test_prime_checker.py
```

## 입력 규칙

| 입력 | 결과 |
|------|------|
| 음수 | `Invalid: Negative number` |
| 0, 1 | `No` |
| 2 ~ 1000 사이 소수 | `Yes` |
| 2 ~ 1000 사이 비소수 | `No` |
| 1000 초과 | `Invalid: Out of range` |
| 숫자가 아닌 문자 | `Invalid: Non-numeric input` |
| 공백 | `Invalid: Blank input` |
