import math


class PrimeChecker:
    @staticmethod
    def check_prime(input_str: str) -> str:
        if PrimeChecker._is_blank(input_str):
            return "Invalid: Blank input"

        try:
            number = int(input_str)
        except ValueError:
            return "Invalid: Non-numeric input"

        if number < 0:
            return "Invalid: Negative number"
        elif number == 0 or number == 1:
            return "No"
        elif number > 1000:
            return "Invalid: Out of range"
        elif PrimeChecker._is_prime(number):
            return "Yes"
        else:
            return "No"

    @staticmethod
    def _is_prime(num: int) -> bool:
        if num <= 1:
            return False
        for i in range(2, int(math.sqrt(num)) + 1):
            if num % i == 0:
                return False
        return True

    @staticmethod
    def _is_blank(s: str) -> bool:
        return s.strip() == ""
