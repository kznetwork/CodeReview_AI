from prime_checker import PrimeChecker


def main():
    print(PrimeChecker.check_prime("-1"))    # Invalid: Negative number
    print(PrimeChecker.check_prime("0"))     # No
    print(PrimeChecker.check_prime("3"))     # Yes
    print(PrimeChecker.check_prime("1000"))  # No
    print(PrimeChecker.check_prime("1001"))  # Invalid: Out of range
    print(PrimeChecker.check_prime("27"))    # No
    print(PrimeChecker.check_prime("r"))     # Invalid: Non-numeric input
    print(PrimeChecker.check_prime(" "))     # Invalid: Blank input


if __name__ == "__main__":
    main()
