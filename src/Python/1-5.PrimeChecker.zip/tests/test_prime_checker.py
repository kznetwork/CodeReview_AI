import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from prime_checker import PrimeChecker


def test_negative_number():
    assert PrimeChecker.check_prime("-1") == "Invalid: Negative number"


def test_zero():
    assert PrimeChecker.check_prime("0") == "No"


def test_prime_number():
    assert PrimeChecker.check_prime("3") == "Yes"


def test_boundary_number_1000():
    assert PrimeChecker.check_prime("1000") == "No"


def test_out_of_range_number():
    assert PrimeChecker.check_prime("1001") == "Invalid: Out of range"


def test_non_prime_number():
    assert PrimeChecker.check_prime("27") == "No"


def test_non_numeric_input():
    assert PrimeChecker.check_prime("r") == "Invalid: Non-numeric input"


def test_blank_input():
    assert PrimeChecker.check_prime(" ") == "Invalid: Blank input"


if __name__ == "__main__":
    test_negative_number()
    test_zero()
    test_prime_number()
    test_boundary_number_1000()
    test_out_of_range_number()
    test_non_prime_number()
    test_non_numeric_input()
    test_blank_input()
    print("All tests passed!")
